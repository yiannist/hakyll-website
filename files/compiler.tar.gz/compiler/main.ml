(*****************************************************************************
  * 
  * Main for Tony Compiler
  * 
  * This file is part of Tonyc. 
  *
  * Tonyc is free software: you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation, either version 3 of the License, or
  * (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  *****************************************************************************)
open Error
open Parsing
open Lexing

open Optimize

(* Initialize to `invalid` values *)
let cin = ref stdin
let quad_out = ref stderr
let asm_out = ref stderr


let main =
  (*----- Parse args start -----*)
  (* Parsing arguments mainly sets the appropriate in/out files. *)
  let usage = Sys.argv.(0) ^ " OPTIONS or " ^ Sys.argv.(0) ^ " FILE"
  and file = ref "" in (* Only changed in anon_fun! *)
  let anon_fun = fun name -> 
    file := name; 
    cin :=  open_in name;
    quad_out := open_out ((Filename.chop_extension name) ^ ".imm");
    asm_out := open_out ((Filename.chop_extension name) ^ ".asm")
  in
  let options = Arg.align 
      [("-f", Arg.Unit (fun _ -> cin := stdin; asm_out := stdout), 
	" Read input from stdin. Generate final code to stdout.");
       ("-i", Arg.Unit (fun _ -> cin := stdin; quad_out := stdout), 
	" Read input from stdin. Generate intermediate code to stdout.")]
       (*("-O", Arg.Unit (fun _ -> Optimize.optimize Intermediate.quad_list),
	" Perform intermediate code optimizations.")]*)
  in
  (*----- Parse args end -----*)
  if Array.length Sys.argv > 1 then begin
    let () = Arg.parse options anon_fun usage in (* Handle args *)
    let lexbuf = Lexing.from_channel !cin in
    if !cin <> stdin then begin
      let pos = lexbuf.lex_curr_p in
      lexbuf.lex_curr_p <- {pos with pos_lnum=pos.pos_lnum; 
			     pos_bol = pos.pos_cnum; pos_fname = !file; }
    end;
    try
      Parser.program Lexer.scanner lexbuf;
      (* Optimize intermediate code! *)
      (*Optimize.optimize Intermediate.quad_list;*)
      if !quad_out <> stderr then
	(* Print quads *)
	Intermediate.print_quads !quad_out;  
      if !asm_out <> stderr then begin
        (* Print asm *)
	Final.oc := !asm_out;
	Final.print_final (); 
      end;
      close_in !cin;
      close_out !quad_out;
      close_out !asm_out;
      if ((!numErrors = 0) && (!numWarnings = 0)) then exit 0
      else exit 1
    with 
      Parsing.Parse_error ->  
	message "%a There is a Parsing error.\n" print_position 
	  (position_point lexbuf.lex_curr_p); 
	exit 1
  end else (* mixed command-line arguments *)
    Arg.usage options usage
