(*****************************************************************************
 * 
 * This file is part of Tonyc. 
 *
 * Tonyc is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
******************************************************************************)
(* Utils module offers some auxilary functions for Tony Compiler *)
open Format
  
open Types
open Identifier
open Symbol

let flag = ref false 
(* Debug mode printing.
 * Tonyc Parser prints information of parsing *)
let print str =
  if !flag then Printf.printf "[parser] %s\n" str else ()

(* Return type of typ *)
let extract_type (t:Types.typ) = 
  match t with
    | TYPE_array (ty, sz) | TYPE_list (ty, sz)  -> ty
    | _ -> t

(* Auxiliary printing functions from Symbtest *)
let show_offsets = true

let rec pretty_typ ppf typ =
  match typ with
    | TYPE_none ->
        fprintf ppf "<undefined>"
    | TYPE_int ->
        fprintf ppf "int"
    | TYPE_byte ->
        fprintf ppf "byte"
    | TYPE_bool ->
        fprintf ppf "bool"
    | TYPE_array (et, sz) ->
        pretty_typ ppf et;
        if sz > 0 then
          fprintf ppf " [%d]" sz
        else
          fprintf ppf " []"
    | TYPE_proc ->
        fprintf ppf "proc"
    | TYPE_char ->
        fprintf ppf "char"
    | TYPE_list (ty, sz) ->
        pretty_typ ppf ty;
        if sz > 0 then
          fprintf ppf " [%d]" sz
        else
          fprintf ppf " []"

let pretty_mode ppf mode =
  match mode with
    | PASS_BY_REFERENCE ->
        fprintf ppf "reference "
    | _ ->
        ()

let printSymbolTable () =
  let rec walk ppf scp =
    if scp.sco_nesting <> 0 then begin
      fprintf ppf "scope: ";
      let entry ppf e =
        fprintf ppf "%a" pretty_id e.entry_id;
        match e.entry_info with
          | ENTRY_none ->
              fprintf ppf "<none>"
          | ENTRY_variable inf ->
              if show_offsets then
                fprintf ppf "[%d]" inf.variable_offset
          | ENTRY_function inf ->
              let param ppf e =
                match e.entry_info with
                  | ENTRY_parameter inf ->
                      fprintf ppf "%a%a : %a"
                        pretty_mode inf.parameter_mode
                        pretty_id e.entry_id
                        pretty_typ inf.parameter_type
                  | _ ->
                      fprintf ppf "<invalid>" in
              let rec params ppf ps =
                match ps with
                  | [p] ->
                      fprintf ppf "%a" param p
                  | p :: ps ->
                      fprintf ppf "%a; %a" param p params ps;
                  | [] ->
                      () in
                fprintf ppf "(%a) : %a"
                  params inf.function_paramlist
                  pretty_typ inf.function_result
          | ENTRY_parameter inf ->
              if show_offsets then
                fprintf ppf "[%d]" inf.parameter_offset
          | ENTRY_temporary inf ->
              if show_offsets then
                fprintf ppf "[%d]" inf.temporary_offset in
      let rec entries ppf es =
        match es with
          | [e] ->
              fprintf ppf "%a" entry e
          | e :: es ->
              fprintf ppf "%a, %a" entry e entries es;
          | [] ->
              () in
        match scp.sco_parent with
          | Some scpar ->
              fprintf ppf "%a\n%a"
                entries scp.sco_entries
                walk scpar
          | None ->
              fprintf ppf "<impossible>\n"
    end in
  let scope ppf scp =
    if scp.sco_nesting == 0 then
      fprintf ppf "no scope\n"
    else
      walk ppf scp in
    printf "%a----------------------------------------\n"
      scope !currentScope

(* Function that decides if v:t is variable or pointer! 
 * This function is used to make appropriate call to consv/consp or 
 * newarrayp/newarrayv. *)
let is_v (t:Types.typ) = 
  match t with
  | TYPE_int | TYPE_byte | TYPE_char | TYPE_bool -> true
  | TYPE_array _ | TYPE_list _ -> false
  | TYPE_none | TYPE_proc -> Error.internal "is_v called with None or Proc type!"; 
      false
     
(* Function that decides if v of 'byte type' needs extension to 'word type'.
 * This function is used in consv and head *)
let needs_extend (t:Types.typ) =
  match t with 
  | TYPE_byte | TYPE_char | TYPE_bool -> true
  | _ -> false
