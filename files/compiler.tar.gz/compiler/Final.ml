(******************************************************************************
 * Module for Final code generator
 * Assembly printing functions plus auxiliary functions
 *
 * 
 * This file is part of Tonyc. 
 *
 * Tonyc is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************)
open Error
open Symbol
open Types

open Intermediate
open Identifier
module I = Intermediate


(* Print assembly functions *)
let oc = ref stdout
let printasm fmt = Printf.fprintf !oc fmt


(* ------ Functions' Offset Manipulation ------ *)
(* A hashtbl that stores (func_entry, func_negofs, func_AR_entries). This is
 * updated before closeScope in Parser. This infrastructure is obligatory as 
 * closing scope would destroy these info.*)
let (func_offset_push, func_offset_pop, func_offset_stack) = 
  let (func_offset_stack:(Symbol.entry, (int * Symbol.entry list)) Hashtbl.t) =
      Hashtbl.create 20 in
  (fun (name, offs, entries) -> Hashtbl.add func_offset_stack name 
      (offs, entries)), 
  (fun (name) -> Hashtbl.find func_offset_stack name),
  (func_offset_stack)


(* ----- Extern Functions Manipulation ----- *)
(* Key: Function name, Value: Type *)
let (externs:(string, string) Hashtbl.t) = Hashtbl.create 25

let print_externs (x:(string, string) Hashtbl.t) = 
  printasm "\n\t;Run-time library functions\n";
  Hashtbl.iter (fun name typ -> printasm "\t\t\textrn\t_%s : %s\n" name typ) x


(* ----- String Manipulation ----- *)
(* ("@str_%s", string) String needs to be parsed for appropriate printing. *)
let (strings:(string * string) list ref) = ref []

(* Unique string identifier *)
let str_id = ref 0

(* Add a string to the list *)
let str_add (s:string) =
  incr str_id;
  let new_s = Printf.sprintf "@str_%d" !str_id in
  strings := (new_s, s) :: !strings;
  new_s

(* fix str returns a string in the proper form for printing at the end of the
 * asm code. 
 * It uses a temporary buffer to create the proper string. *)
let fix_str (s:string) =
  let escape_map = Hashtbl.create 6 in (* Map esc chars to ascii codes *)
  let len = String.length s in
  let buf = Buffer.create len in    (* Buffer that holds returned string *)
  let tmp= Buffer.create len in     (* Intermediate buffer for regular chars *)
  let esc_mode = ref false in       (* Next char is part of an escape char *)
  let proper_char (c:char) =
    if (Char.compare c '\\')==0 then esc_mode := true (* avoid Escape Char *)
    else begin
      if !esc_mode && (Hashtbl.mem escape_map c) then begin
        esc_mode := false;
        (* Flush tmp into buf because string (without escs) is complete *)
        if (Buffer.length tmp)<>0 then begin 
          Printf.bprintf buf "\t\tdb\t'%s'\n" (Buffer.contents tmp);
          Buffer.clear tmp
        end;
        Printf.bprintf buf "\t\t\tdb\t%d\n" (Hashtbl.find escape_map c)
      end else
        Buffer.add_char tmp c
    end
  in
  let strip_quotes (s:string) = 
    String.sub s 1 (len - 2)
  in
  let () = List.iter (fun (x, y) -> Hashtbl.add escape_map x y) 
             ['n',10;'t',09;'r',13;'\\',92;'\'',39;'\"',34] 
  in
    String.iter proper_char (strip_quotes s);
    if Buffer.length tmp <> 0 then 
      (* Flush in case of no escs or remainder *)
      Printf.bprintf buf "\t\tdb\t'%s'\n" (Buffer.contents tmp);
    Buffer.add_string buf "\t\t\tdb\t0\n"; (*Add '\0' at the end of every string*)
    Buffer.contents buf
    
(* Print all strings _before_ program's footer *)
let print_strings (strs:(string * string) list) = 
  printasm "\n\t;String constants\n";
  ignore (List.map (fun (s_head,s) -> 
                      printasm "%s" s_head; 
                      printasm "%s" (fix_str s)) 
    strs)

(* ------------------------------- 
 * ----- Auxiliary functions -----
 * ------------------------------- *)

(* We need a second stack of functions to be able to find all function symbol
 * entries that were created during execution. We never remove a function from
 * this structure (we need info for unit/endu asm code).
 * Top_aux_func_stack is used for extracting `current unit` name for GC (messy!)
 *)
let (aux_func_stack, top_aux_func_stack) =
  let (aux_func_stack:(Symbol.entry * int) list ref) = ref [] in
  (aux_func_stack, 
   (fun () -> 
     match !aux_func_stack with 
     | (e, i)::t -> ( (id_name e.entry_id), i )
     | [] -> ("_error_",1) ) )


(* Note down the current scope as we parse the quad_list.
 * Updated at unit/endu quad *)
let current_nest_lvl = ref 0

(* Get scope of Symbol Entry a *)
let scope (a:Symbol.entry) = a.entry_scope.sco_nesting 

(* Is Symbol Entry a a local entity? *)
let is_local (a:Symbol.entry) = ((scope a) = !current_nest_lvl)

(* Get unique function id for Symbol Entry e *)
let get_uid (e:Symbol.entry) =
  match e.entry_info with
  | ENTRY_function f -> f.function_uniq_id;
  | _ -> internal "Cannot get Unique Function Id from non-function entity."; 
         -1

(* Is external function (builtin) or not? (hint: check function_uniq_id) *)
let is_extern (a:Symbol.entry) = 
  get_uid a = 0

(* Get activation record offset of Symbol Entry a *)
let offset (a:Symbol.entry) = 
  match a.entry_info with
  | ENTRY_variable v -> v.variable_offset
  | ENTRY_parameter p -> p.parameter_offset
  | ENTRY_temporary t -> t.temporary_offset
  | _ -> (* never matched *)
      internal "Request for offset of non-variable, non-parameter, non-temporary \
	entity"; 0 

(* Return word/byte by peeking at the type of a Symbol Entry *)
let size (a:Symbol.entry) =
  let rec _size (t:Types.typ) =
    match t with 
    | TYPE_int  -> "word"
    | TYPE_bool | TYPE_char -> "byte"
    | TYPE_list (ty, _) | TYPE_array (ty, _) -> "word"
    | _ -> "WRONG!"
  in
  match a.entry_info with
  | ENTRY_variable v -> (_size v.variable_type)
  | ENTRY_parameter p -> (_size p.parameter_type)
  | ENTRY_temporary t -> (_size t.temporary_type)
  | _ -> (* never matched *)
    internal "Request for size of non-variable, non-parameter, non-temporary \
	entity."; (_size TYPE_none) 


(* Categorize entity a as BY_VALUE_LOCAL / BY_REF *)
type category = BY_VALUE_LOCAL | BY_REF | INVAL
let categorize (a:Symbol.entry) = 
  match a.entry_info with
  | ENTRY_temporary _ | ENTRY_variable _ -> BY_VALUE_LOCAL
  | ENTRY_parameter p -> begin
      match p.parameter_mode with
      | PASS_BY_VALUE -> BY_VALUE_LOCAL
      | PASS_BY_REFERENCE -> BY_REF
  end
  | _ -> (* never matched *)
    internal "Cannot categorize non-variable, non-parameter, non-temporary \
    entity."; INVAL

(* Get Int of Label Int. Applied to I.operand_t *)
let extract_label (opand:I.operand_t) = 
  match opand with
    | Label i -> i
    | _ -> internal "Cannot extract_label of operand_t that it is not a Label";
           -1

(*-----------------------------------------------------------*)
(*--------------- Book's auxiliary functions -----------------*)
(*-----------------------------------------------------------*)

(* Load address base for non-local entity a (quad operand) *)
let getAR (a:I.operand_t) = 
  let n_a = 
    match a with 
    | I.Entry e -> scope e
    | _ -> (* must never match *)
      internal "Cannot find nesting level of non-Symbol Entry entity"; 0 
  in
  let n = !current_nest_lvl - n_a - 1 in
    assert(n>=0);
    printasm "\t\t\tmov\t\tsi, word ptr [bp+4]\n";
    for i=1 to n do printasm "\t\t\tmov\t\tsi, word ptr [si+4]\n" done

(* Update access link of callee function _before_ call *)
let updateAL (a:I.operand_t) =
  match a with
  | I.Entry x -> 
      let n_p = !current_nest_lvl 
      and n_x = 
        if is_extern x then 
          Pervasives.max_int
        else
          scope x + 1
      in
      if n_p < n_x then printasm "\t\t\tpush\tbp\n"
      else if n_p = n_x then printasm "\t\t\tpush\tword ptr [bp+4]\n"
      else begin
        let n = n_p-n_x-1 in
          printasm "\t\t\tmov\t\tsi, word ptr [bp+4]\n";
          for i=1 to n do printasm "\t\t\tmov\t\tsi, word ptr [si+4]\n" done;
          printasm "\t\t\tpush\tword ptr [si+4]\n";
      end
  | _ -> internal "Cannot update Access Link L of non-entry entity"

(* Load data of quad operand a to register R *)
let rec load (r:string) (a:I.operand_t) =
  match a with
  | Int i   -> printasm "\t\t\tmov\t\t%s, %d\n" r i
  | Boole b -> begin
    match b with
    | true  -> printasm "\t\t\tmov\t\t%s, %d\n" r 1
    | false -> printasm "\t\t\tmov\t\t%s, %d\n" r 0
  end
  | Char c  -> printasm "\t\t\tmov\t\t%s, %d\n" r (Char.code c)
  | Str s -> printasm "\t\t\tlea\t\t%s, byte ptr %s\n" r (str_add s)
  | Nil     -> printasm "\t\t\tmov\t\t%s, %d\n" r 0
  | Pointer (e, t) -> 
      load "di" (I.Entry e);
      if (Types.sizeOfType t == 2) then
	printasm "\t\t\tmov\t\t%s, word ptr [di]\n" r 
      else
	printasm "\t\t\tmov\t\t%s, byte ptr [di]\n" r 
  | Entry e -> 
      if (is_local e) then begin
        if (categorize e) = BY_VALUE_LOCAL then
          if offset e < 0 then
            printasm "\t\t\tmov\t\t%s, %s ptr [bp%d]\n" r (size e) (offset e)
          else
            printasm "\t\t\tmov\t\t%s, %s ptr [bp+%d]\n" r (size e) (offset e)
        else begin
          if offset e < 0 then
            printasm "\t\t\tmov\t\tsi, %s ptr [bp%d]\n" (size e) (offset e)
          else
            printasm "\t\t\tmov\t\tsi, %s ptr [bp+%d]\n" (size e) (offset e);
          printasm "\t\t\tmov\t\t%s, %s ptr [si]\n" r (size e)
        end
      end else begin(* non-local entity *)
        if (categorize e) = BY_VALUE_LOCAL then begin
          getAR a;
          if offset e < 0 then 
            printasm "\t\t\tmov\t\t%s, %s ptr [si%d]\n" r (size e) (offset e)
          else
            printasm "\t\t\tmov\t\t%s, %s ptr [si+%d]\n" r (size e) (offset e);
        end else begin
          getAR a;
          if offset e < 0 then 
            printasm "\t\t\tmov\t\tsi, %s ptr [si%d]\n" (size e) (offset e)
          else
            printasm "\t\t\tmov\t\tsi, %s ptr [si+%d]\n" (size e) (offset e);
          printasm "\t\t\tmov\t\t%s, %s ptr [si]\n" r (size e);
        end
      end
  | _ -> internal "Problem with load to reg function"

(* Load address of quad operand a*)
let loadAddr (r:string) (a:I.operand_t) = 
  match a with
  | Str s -> 
      printasm "\t\t\tlea\t\t%s, byte ptr %s\n" r (str_add s)
  | Entry e ->
      if (is_local e) then begin
        if (categorize e) = BY_VALUE_LOCAL then
          if offset e < 0 then 
            printasm "\t\t\tlea\t\t%s, %s ptr [bp%d]\n" r (size e) (offset e)
          else
            printasm "\t\t\tlea\t\t%s, %s ptr [bp+%d]\n" r (size e) (offset e)
        else
          if offset e < 0 then 
            printasm "\t\t\tmov\t\t%s, word ptr [bp%d]\n" r (offset e)
          else
            printasm "\t\t\tmov\t\t%s, word ptr [bp+%d]\n" r (offset e)
      end else begin(* non-local entity *)
        if (categorize e) = BY_VALUE_LOCAL then begin
          getAR a;
          if offset e < 0 then 
            printasm "\t\t\tlea\t\t%s, %s ptr [si%d]\n" r (size e) (offset e)
          else
            printasm "\t\t\tlea\t\t%s, %s ptr [si+%d]\n" r (size e) (offset e)
        end else begin
          getAR a;
          if offset e < 0 then 
            printasm "\t\t\tmov\t\t%s, %s ptr [si%d]\n" r (size e) (offset e)
          else
            printasm "\t\t\tmov\t\t%s, %s ptr [si+%d]\n" r (size e) (offset e)
        end
      end
  | Pointer (e,_) -> load r (I.Entry e)
  | Nil -> load r (I.Int 0)
  | _ -> internal "Problem with loadAddr function"

(* Store data of register R to quad operand a *)
let store (r:string) (a:I.operand_t) =
  match a with
  | Entry e -> 
      if (is_local e) then begin
        if (categorize e) = BY_VALUE_LOCAL then
          if offset e < 0 then
            printasm "\t\t\tmov\t\t%s ptr [bp%d], %s\n" (size e) (offset e) r
          else
            printasm "\t\t\tmov\t\t%s ptr [bp+%d], %s\n" (size e) (offset e) r
        else begin
          if offset e < 0 then 
            printasm "\t\t\tmov\t\tsi, %s ptr [bp%d]\n" (size e) (offset e)
          else 
            printasm "\t\t\tmov\t\tsi, %s ptr [bp+%d]\n" (size e) (offset e);
          printasm "\t\t\tmov\t\t%s ptr [si], %s\n" (size e) r
        end
      end else begin(* non-local entity *)
        if (categorize e) = BY_VALUE_LOCAL then begin
          getAR a;
          if offset e < 0 then 
            printasm "\t\t\tmov\t\t%s ptr [si%d], %s\n" (size e) (offset e) r
          else
            printasm "\t\t\tmov\t\t%s ptr [si+%d], %s\n" (size e) (offset e) r
        end else begin
          getAR a;
          if offset e < 0 then 
            printasm "\t\t\tmov\t\tsi, %s ptr [si%d]\n" (size e) (offset e)
          else
            printasm "\t\t\tmov\t\tsi, %s ptr [si+%d]\n" (size e) (offset e);
          printasm "\t\t\tmov\t\t%s ptr [si], %s\n" (size e) r;
        end
      end
  | Pointer (e, t) -> 
      load "di" (I.Entry e);
      if (Types.sizeOfType t == 2) then
	printasm "\t\t\tmov\t\tword ptr [di], %s\n" r
      else
	printasm "\t\t\tmov\t\tbyte ptr [di], %s\n" r


  | Result t -> (* :=, x, -, z *)
      (* Function's result is stored in activation record at bp+6 *)
      printasm "\t\t\tmov\t\tsi, word ptr [bp+6]\n";
      if (Types.sizeOfType t = 1) then
	printasm "\t\t\tmov\t\tbyte ptr [si], al\n"
      else
	printasm "\t\t\tmov\t\tword ptr [si], ax\n"
  | _ -> internal "Problem with store from reg to a function"

(* Generator of unique labels for units *)
let name (p:I.operand_t) = 
  match p with
  | Entry fname -> 
    Printf.sprintf "_%s_%d" (id_name fname.entry_id) (get_uid fname)
  | _ -> 
    internal "Cannot generate unit label for non-string operand"; "BLOUP1"

let endof (p:I.operand_t) = 
  match p with
  | Entry fname -> 
    Printf.sprintf "@%s_%d" (id_name fname.entry_id) (get_uid fname)
  | _ -> 
    internal "Cannot generate unit label for non-string operand"; "CLOUP1"

let label (n:int) = Printf.sprintf "@%d" n



(* -------------------------------
 * ----- Asm Code Generation -----
 * ------------------------------- *)

let header = 
  "xseg\t\tsegment\tpublic 'code'\n\
   \t\t\tassume\tcs:xseg, ds:xseg, ss:xseg\n\
   \t\t\torg\t\t100h\n\n\
   main\t\tproc\tnear\n\
   \t;; initialize memory: 2/3 heap and 1/3 stack\n\
   \t\t\tmov\t\tcx, OFFSET DGROUP:_start_of_space\n\
   \t\t\tmov\t\tword ptr _space_from, cx\n\
   \t\t\tmov\t\tword ptr _next, cx\n\
   \t\t\tmov\t\tax, 0FFFEh\n\
   \t\t\tsub\t\tax, cx\n\
   \t\t\txor\t\tdx, dx\n\
   \t\t\tmov\t\tbx, 3\n\
   \t\t\tidiv\tbx\n\
   \t\t\tand\t\tax, 0FFFEh ; even number!\n\
   \t\t\tadd\t\tcx, ax\n\
   \t\t\tmov\t\tword ptr _limit_from, cx\n\
   \t\t\tmov\t\tword ptr _space_to, cx\n\
   \t\t\tadd\t\tcx, ax\n\
   \t\t\tmov\t\tword ptr _limit_to, cx\n"

(* Keep track of extern functions' usage and register call tables *)
let (push_extern_call_table, print_extern_call_tables) =
  let (extern_call_tables: string list ref) = ref [] in
  (fun func_name -> 
    if not (List.mem func_name !extern_call_tables) then
      extern_call_tables := func_name :: !extern_call_tables
    else ()),
  (fun print_func -> List.iter print_func !extern_call_tables)

(* Function that adds call_table registration info in header *)
let reg_call_tables () =
   (* Register call table for Name *)
   let print_reg_call_table (name:string) =
     printasm "\t\t\tmov\t\tax, OFFSET %s_call_table\n" name;
     (*if not (List.mem name 
	       ["_newarrv";"_newarrp";"_shrink";"_extend";"_head";"_tail"]) then *)
       (* only consv/cosnp have call table! *)
       printasm "\t\t\tcall\tnear ptr _register_call_table\n" 
   in
   printasm "\t;; Register call tables\n";
   (* Register call tables for -all- user functions *)
   Hashtbl.iter (fun entry offset -> print_reg_call_table (name (I.Entry entry))) 
     func_offset_stack;
   (* Register call tables for externs *)
   print_extern_call_tables print_reg_call_table

let end_header (name:string) =
   printasm "\t;; call main\n\
   \t\t\tcall\tnear ptr %s\n\
   _ret_of_main:\n\
   \t;; exit with code 0\n\
   \t\t\tmov\t\tax, 4C00h\n\
   \t\t\tint\t\t21h\n\
   main\t\tendp\n\n\n" name
 
let gc_footer = 
  "\n\t;;public gc vars\n\
   \t\t\tpublic\t_next\n\
   \t\t\tpublic\t_space_from\n\
   \t\t\tpublic\t_space_to\n\
   \t\t\tpublic\t_limit_from\n\
   \t\t\tpublic\t_limit_to\n\
   \t\t\tpublic\t_ret_of_main\n\
   \n_next\t\tdw\t\t?\n\
   _space_from\tdw\t\t?\n\
   _space_to\tdw\t\t?\n\
   _limit_from\tdw\t\t?\n\
   _limit_to\tdw\t\t?\n"

let footer =
  "\n\t\t\txseg\tends\n\
   \n_DATA_END\t\tsegment\tbyte public 'stack'\n\
    _start_of_space\tlabel\tbyte\n\
    _DATA_END\t\tends\n\
    \nDGROUP\t\tgroup\txseg, _DATA_END\n\
    \n\t\t\tend\t\tmain\n"

(* Calls of current unit *)
let (push_call, get_call_list, reset_call_list, get_next_call_id) = 
  let id = ref 0 in
  let (call_list:(int * bool * int) list ref) = ref [] in
  ((fun (new_call_params:int) -> 
    call_list := begin
      match !call_list with
      |	(x, y, z) :: t -> (x, true, z) :: t
      |	[] -> []
    end;
    incr id;
    call_list := (!id, false, new_call_params) :: !call_list),
   (fun () -> List.rev !call_list),
   (fun () -> id := 0; call_list := []),
   (fun () -> !id))
	    
(* Ubber function for transforming quads to ASM code *)
let extract_quad (q:I.quad) = (q.label, q.opor, q.opand1, q.opand2, q.opand3)

let asm_gen (q:I.quad) = 
  let print_comment_quad (q:I.quad) = printasm "\t;; "; I.print_quad !oc q in
  let q_no, op, o1, o2, o3 = extract_quad q in 
  match op with 
  | I.O_Assign -> 
      print_comment_quad q; 
      printasm "%s:\n" (label q_no);
      (* Check size of operand *)
      if (I.sizeof_operand o1) = 1 then begin
        load "al" o1;
        store "al" o3
      end else begin
        load "ax" o1;
        store "ax" o3
      end 
  | I.O_Array ->
    print_comment_quad q;
    printasm "%s:\n" (label q_no);
    let sizeof_array_operand = function
    |  TYPE_array (t, _) -> Types.sizeOfType t
    | _ -> internal "sizeof_array_operand: Expected TYPE_array argument"; 0
    in
    load "ax" o2;
    printasm "\t\t\tmov\t\tcx, %d\n" (I.sizeof_operand ~sizeof:sizeof_array_operand o1); 
    printasm "\t\t\timul\tcx\n";
    load "cx" o1;
    printasm "\t\t\tadd\t\tax, cx\n";
    store "ax" o3
  | I.O_Plus ->
    print_comment_quad q;
    printasm "%s:\n" (label q_no);
    load "ax" o1;
    load "dx" o2;
    printasm "\t\t\tadd\t\tax, dx\n";
    store "ax" o3
  | I.O_Minus -> begin
      print_comment_quad q;
      printasm "%s:\n" (label q_no);
      match o2 with 
      | I.Empty -> (* Take special care if it minus sign *)
	  load "ax" o1;
	  printasm "\t\t\tneg\t\tax\n";
	  store "ax" o3
      |	_ -> (* Do ordinary substraction *)
	  load "ax" o1;
	  load "dx" o2;
	  printasm "\t\t\tsub\t\tax, dx\n";
	  store "ax" o3
      end
  | I.O_Mult ->
    print_comment_quad q;
    printasm "%s:\n" (label q_no);
    load "ax" o1;
    load "cx" o2;
    printasm "\t\t\timul\tcx\n";
    store "ax" o3
  | I.O_Div ->
    print_comment_quad q;
    printasm "%s:\n" (label q_no);
    load "ax" o1;
    printasm "\t\t\tcwd\n";
    load "cx" o2;
    printasm "\t\t\tidiv\tcx\n";
    store "ax" o3
  | I.O_Mod ->
    print_comment_quad q;
    printasm "%s:\n" (label q_no);
    load "ax" o1;
    printasm "\t\t\tcwd\n";
    load "cx" o2;
    printasm "\t\t\tidiv\tcx\n";
    store "dx" o3
  | I.O_Equal | I.O_Nequal | I.O_Greater | I.O_Less | I.O_Lequal | I.O_Gequal->
    print_comment_quad q;
    printasm "%s:\n" (label q_no);
    load "ax" o1;
    load "dx" o2;
    printasm "\t\t\tcmp\t\tax, dx\n";
    let action = 
      match op with 
      | I.O_Equal   -> "je" 
      | I.O_Nequal  -> "jne"
      | I.O_Greater -> "jg"
      | I.O_Less    -> "jl" 
      | I.O_Lequal  -> "jle"
      | I.O_Gequal  -> "jge"
      | _           -> "_err_" (* must never match! *)
    in
      printasm "\t\t\t%s\t\t%s\n" action (label (extract_label o3))
  | I.O_If_jump ->
    print_comment_quad q;
    printasm "%s:\n" (label q_no);
    load "al" o1;
    printasm "\t\t\tor\t\tal, al\n";
    printasm "\t\t\tjnz\t\t%s\n" (label (extract_label o3))
  | I.O_Unit -> begin
    match o1 with 
    | Entry e ->
      (* Update current nesting level *)
      current_nest_lvl := scope e + 1;
      (* Store for usage in ret quad *)
      aux_func_stack := (e, get_uid e) :: !aux_func_stack;
      print_comment_quad q;
      printasm "%s:\n" (label q_no);
      printasm "%s\t%s" (name o1) "proc\tnear\n";
      printasm "\t\t\tpush\tbp\n\
        \t\t\tmov\t\tbp, sp\n";
      (*---- GC: Reset list of call_tables ----*)
      reset_call_list ();
      let (negofs,_) = func_offset_pop e in
      if (negofs < 0) then begin
	(*---- GC: Initialize stack to 0 ----*)
	(*printasm "\t\t\tsub\t\tsp, %d\n" (- negofs);*)
	printasm "\t\t\txor\t\tax, ax\n";
	let pushes = - negofs / 2 in 
	for i=1 to pushes do printasm "\t\t\tpush\tax\n" done;
	if - negofs mod 2 == 1 then begin (* XXX: May be bug here! *)
	  printasm "\t\t\tsub\t\tsp, 1\t\t;odd negative offset correction\n";
	  printasm "\t\t\tmov\t\tsi, sp\n";
	  printasm "\t\t\tmov\t\tbyte ptr [si], al\n";
	end
      end
    | _ -> internal "No can't do sir. Unit quad with operand1 not being a \
        Symbol Entry. Pots genen auto?"
  end
  | I.O_Endu -> begin
      match o1 with 
      |	I.Entry e -> begin
      	  print_comment_quad q;
	  printasm "%s:\n" (label q_no);
	  printasm "%s:\n\t\t\tmov\t\tsp, bp\n\
            \t\t\tpop\t\tbp\n\
            \t\t\tret\n" (endof o1); 
	  printasm "%s\tendp\n\n" (name o1);
          (* GC: Start of Call Tables *)
	  printasm "%s_call_table:\n" (name o1);
	  let print_call_i ((i:int), (hasNext:bool), (addSP:int)) = 
	    let (active_func, act_id) = top_aux_func_stack () 
	    and (negoffs, entries) = func_offset_pop e 
	    and print_critical_words (e:Symbol.entry) = 
	      let is_pointer =
		  match e.entry_info with
		  | ENTRY_variable e -> not (Utils.is_v e.variable_type)
		  | ENTRY_parameter e -> not (Utils.is_v e.parameter_type)
		  | ENTRY_temporary e -> not (Utils.is_v e.temporary_type)
		  | _ -> false
	      in
	      if is_pointer then
		printasm "\t\tdw %d\n" (offset e);
	    in
	    printasm "@call_%d_%d\tdw @%s_%d_call_%d\n" act_id i active_func act_id i;
	    if hasNext then printasm "\t\tdw @call_%d_%d\n" act_id (i+1)
	    else printasm "\t\tdw 0\n";
	    printasm "\t\tdw %d\n" (addSP - negoffs + 4);
	    (* Word 4-(n-1): Add pointers-to-heap offset in activation rec *)
	    List.iter print_critical_words (List.rev entries);
	    printasm "\t\tdw 0\n";
	  in
	  List.iter print_call_i (get_call_list ());
          (* Endof `current` unit. Make the change! *)
	  aux_func_stack := List.tl !aux_func_stack;    
      end
      | _ -> internal "No can't do sir. Unit quad with operand1 not being a \
	    Symbol Entry. Pots genen auto?"
  end
  | I.O_Par -> begin
      print_comment_quad q;
      printasm "%s:\n" (label q_no);
      match o2 with
      | I.Pass p -> 
          if p = V then begin
            if (I.sizeof_operand o1) <> 1 then begin
              load "ax" o1;
              printasm "\t\t\tpush\tax\n"
            end else begin
              load "al" o1;
              (*printasm "\t\t\tsub\t\tsp, 1\n\
                \t\t\tmov\t\tsi, sp\n\
                \t\t\tmov\t\tbyte ptr [si], al\n"; *) 
	      printasm "\t\t\tmov\t\tsi, sp\n\
		 \t\t\tmov\t\tbyte ptr [si-1], 0\n\
		 \t\t\tmov\t\tbyte ptr [si-2], al\n\
		 \t\t\tsub\t\tsp, 2\n";
            end 
          end else begin(* p = R or RET *)
            loadAddr "si" o1;
            printasm "\t\t\tpush\tsi\n";
          end
      | _ -> internal "No can't do. Par quad with operand3 not Pass Mode"
  end
  | I.O_Call ->
      print_comment_quad q;
      printasm "%s:\n" (label q_no);
      let size_of_params (f:Symbol.function_info) = 
        match f.function_paramlist with
        | [] -> 0
        | h :: t -> begin
          match h.entry_info with
          | ENTRY_parameter p -> 
              (* The first parameter of the function is the TOP element in
               * function's Activation Record. Parameters start at bp + 8. *)
              p.parameter_offset - 8 + Symbol.sizeof_parameter p
          | _ -> internal "Call quad: expected parameter in param_list"; 0
        end
      in begin
        match o3 with
        | I.Entry e -> begin
          (* We have to check if function is Proc or Func. *)
          match e.entry_info with
          | ENTRY_function f ->
             if f.function_result = TYPE_proc then
               printasm "\t\t\tsub\t\tsp, 2\n";
             updateAL o3;
             if f.function_uniq_id == 0 then begin
               (* If it is a call to an external function, keep track of it. *)
               (* Builtins shouldn't follow user functions' naming convention *)
               printasm "\t\t\tcall\tnear ptr _%s\n" (id_name e.entry_id);
               (* GC: add return address of call, first dw *)
	       push_call (4 + size_of_params f);
	       let (active_func, act_id) = top_aux_func_stack () in
	       printasm "@%s_%d_call_%d:\n" active_func act_id (get_next_call_id ());
               try
                 ignore(Hashtbl.find externs (id_name e.entry_id))
               with
               Not_found -> Hashtbl.add externs (id_name e.entry_id) "proc"
             end else begin
		 printasm "\t\t\tcall\tnear ptr %s\n" (name o3);
	         (* GC: add return address of call, first dw *)
		 push_call (4 + size_of_params f);
		 let (active_func,act_id) = top_aux_func_stack () in
		 printasm "@%s_%d_call_%d:\n" active_func act_id (get_next_call_id ());
	     end;
             printasm "\t\t\tadd\t\tsp, %d\n" (4 + size_of_params f)
          | _ -> internal "Call quad: expected function_info entry"
        end
	| I.Head | I.Tail -> begin
	    let name = I.str_of_operand o3 in
	    printasm "\t\t\tpush\tbp\n";
	    printasm "\t\t\tcall\tnear ptr _%s\n" name;
            (* GC: add return address of call *)
	    push_call (4 + 2);
	    let (active_func,act_id) = top_aux_func_stack () in
	    printasm "@%s_%d_call_%d:\n" active_func act_id (get_next_call_id ());
	    begin
	    try
	      ignore (Hashtbl.find externs name)
	    with
	      Not_found -> Hashtbl.add externs name "proc"
	    end;
	    printasm "\t\t\tadd\t\tsp, %d\n" (4 + 2) (* fixed size! trust me :) *)
	end
        (*| I.NilQ -> 
	    (* A list is nil iff pointer to list is 0 *)
	    printasm "\t\t\tpop\t\tbx\t\t ;get result place\n";
	    printasm "\t\t\tpop\t\tax\t\t ;get list pointer\n";
	    printasm "\t\t\tor\t\tax, ax\n";
	    printasm "\t\t\tjz\t\tnilnilnil_%d\n" !nilq_count;
	    printasm "\t\t\tmov\t\tbyte ptr [bx], 0\t ; if ax<>0: return false\n";
	    printasm "\t\t\tjmp\t\tnilnilnil_out_%d\n" !nilq_count;
	    printasm "\t\tnilnilnil_%d:\n" !nilq_count; 
	    printasm "\t\t\tmov\t\tbyte ptr [bx], 1\t ; if ax=0=nil: return true\n";
	    printasm "\t\tnilnilnil_out_%d:\n" !nilq_count;
	    incr nilq_count*)
	| I.Consv | I.Consp ->
	    let name = I.str_of_operand o3 in
	    printasm "\t\t\tpush\tbp\n";
	    printasm "\t\t\tcall\tnear ptr _%s\n" name;
	    (* GC: add return address of call *)
	    push_call (4 + 2 + 2);
	    let (active_func,act_id) = top_aux_func_stack () in
	    printasm "@%s_%d_call_%d:\n" active_func act_id (get_next_call_id ());
	    begin
	    try
	      ignore (Hashtbl.find externs name)
	    with
	      Not_found -> 
		Hashtbl.add externs name "proc";
		Hashtbl.add externs (name^"_call_table") "word"
	    end;
	    printasm "\t\t\tadd\t\tsp, %d\n" (4 + 2 + 2)
	| I.Newv | I.Newp | I.Extend | I.Shrink -> 
	    let name = I.str_of_operand o3 in
	    printasm "\t\t\tpush\tbp\n";
	    printasm "\t\t\tcall\tnear ptr _%s\n" name;
            (* GC: add return address of call *)
	    push_call (4 + 2);
	    let (active_func,act_id) = top_aux_func_stack () in
	    printasm "@%s_%d_call_%d:\n" active_func act_id (get_next_call_id ());
	    begin
	    try
	      ignore (Hashtbl.find externs name)
	    with
	      Not_found -> 
		 Hashtbl.add externs name "proc"
	    end;
	    printasm "\t\t\tadd\t\tsp, %d\n" (4 + 2)
        | _ -> internal "Call quad: expected entity of symbol entry"
      end
  | I.O_Ret ->
      print_comment_quad q;
      printasm "%s:\n" (label q_no);
      (* We need `endof(current)` block. We take current from func_stack *)
      let (e, _) = List.hd !aux_func_stack in
      printasm "\t\t\tjmp\t\t%s\n" (endof (I.Entry e))
  | I.O_Jump | I.O_Jump_l ->
      print_comment_quad q;
      printasm "%s:\n" (label q_no);
      printasm "\t\t\tjmp\t\t%s\n" (label (extract_label o3))
  | I.O_Label ->
      print_comment_quad q;
      printasm "%s:\n" (label q_no);
      printasm "%s:" (label (extract_label o3))

(* Final code generation and printing routine *)
let print_final () =
  let (_, _, main, _, _) = extract_quad (List.hd !I.quad_list) in
  let quads = I.get_quads () in
  (* Final unit-endu block is Main's block. We set the appropriate call at asm's
   * header. *)
  let main_name = name main in
  printasm "%s" header;
  reg_call_tables ();
  end_header main_name;
  (* Generate and print main assembly *)
  Hashtbl.add externs "register_call_table" "proc";
  ignore(List.map asm_gen quads);
  (* Print footer *)
  print_externs externs;
  print_strings (List.rev !strings);
  printasm "%s" gc_footer;
  printasm "%s" footer

