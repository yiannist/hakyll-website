(*****************************************************************************
 * 
 * This file is part of Tonyc. 
 *
 * Tonyc is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
******************************************************************************)
open Printf

type typ = TYPE_none
         | TYPE_proc
         | TYPE_int
         | TYPE_byte  
         | TYPE_array of
             typ *
             int
         | TYPE_char
         | TYPE_bool
         | TYPE_list of 
             typ *            (* element type *)
             int              (* current number of elements *)

let rec sizeOfType t =
   match t with
   | TYPE_int            -> 2
   | TYPE_byte           -> 1
   | TYPE_char           -> 1
   | TYPE_bool           -> 1
   | TYPE_array (et, sz) -> 2 (*sz * sizeOfType et*)
   | TYPE_list (ty, size)-> 2 (*size * sizeOfType ty*)
   | _                   -> 0

let rec equalType t1 t2 =
   match t1, t2 with
   | TYPE_array (et1, sz1), TYPE_array (et2, sz2)   -> equalType et1 et2
   | TYPE_list (ty1, sz1), TYPE_list (ty2, sz2) -> 
       (* Hack: Empty list '[]' is equal (in type) with any other list type. *)
       if (sz1 = 0 || sz2 = 0) then 
         true
       else
         equalType ty1 ty2
   | _                                              -> t1 = t2

let rec string_of_type ty = 
    match ty with
   | TYPE_none -> sprintf "none"
   | TYPE_int -> sprintf "int"
   | TYPE_byte -> sprintf "byte"
   | TYPE_array (ty, sz) -> sprintf "array of %s" (string_of_type ty)
   | TYPE_list (ty, sz) -> sprintf "list of %s" (string_of_type ty)
   | TYPE_proc -> sprintf "proc"
   | TYPE_char -> sprintf "char"
   | TYPE_bool -> sprintf "bool"

