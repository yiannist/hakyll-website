(* -------------------------------
 * ----- Module Intermediate -----
 * -------------------------------
 *
 * Auxilary functions for Intermediate code generation and manipulation. *)
(*****************************************************************************
 * 
 * This file is part of Tonyc. 
 *
 * Tonyc is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
******************************************************************************)

open Symbol
open Error
module S = Symbol


(* New Datatypes definition *)
type operator_t = 
  | O_Unit | O_Endu 
  | O_Array 
  | O_Plus | O_Minus| O_Mult | O_Div | O_Mod | O_Assign 
  | O_Equal| O_Nequal | O_Greater | O_Less | O_Lequal | O_Gequal 
  | O_If_jump | O_Jump | O_Label | O_Jump_l 
  | O_Call | O_Par | O_Ret 
and pm_t = R | V | RET
and operand_t = 
  | Int of int
  | Char of char
  | Str of string
  | Boole of bool
  | Invalid          (* No position specified. PLACE initializer *)
  | Label of int     (* Number of quad for jumps *)
  | Pass of pm_t     (* In case of parameter passing *)
  | Backpatch        
  | Empty          
  | Result of Types.typ
  | Nil
  | Pointer of Symbol.entry * Types.typ
  | Entry of Symbol.entry
  (* External function calls *)
  | Head | Tail | Consp | Consv
  | Newp | Newv | Extend | Shrink
and quad = {
  label : int;
  mutable opor : operator_t;
  opand1 : operand_t;
  opand2 : operand_t;
  mutable opand3 : operand_t; (* for backpatching *)
}

(* Returns the _number_ of next quad *)
let nextQuad () =
  !Symbol.quadNext

  (* Generates new quad and _increases_ global Quads next number*)
let genQuad op x y z = 
  let q = {
    label = nextQuad ();
    opor = op;
    opand1 = x;
    opand2 = y;
    opand3 = z;
}
  in 
  incr Symbol.quadNext;
  q


(* Translate operator_t to binary function *)
let binop_of_operator = function
   | O_Plus  -> (+)
   | O_Minus -> (-)
   | O_Mult  -> ( * )
   | O_Div   -> (fun x y -> 
       if y==0 then begin fatal "Division by zero"; x / y end else x / y)
   | O_Mod   -> (fun x y -> 
       if y==0 then begin fatal "Division by zero"; x mod y end else x mod y)
   | _       -> error "Op_of_operator: binary operator not matched."; 
     ( * ) (* Should never execute*)

(* Translate operator_t to binary relation function *)
let relop_of_operator = function
   | O_Equal -> (==)
   | O_Nequal-> (!=)
   | O_Greater -> (>)
   | O_Less  -> (<)
   | O_Lequal-> (<=)
   | O_Gequal-> (>=)
   | _       -> error "Relop_of_operator: Relation operator not matched.";
     ( <> ) (* Should never execute*)

    
(* Useful functions for printing quadraples *)
let str_of_operator = function
  | O_Unit  -> "unit"
  | O_Endu  -> "endu"
  | O_Array -> "array"
  (**)
  | O_Plus  -> "+"
  | O_Minus -> "-"
  | O_Mult  -> "*"
  | O_Div   -> "/"
  | O_Mod   -> "%"
  | O_Assign-> ":="
  | O_Equal -> "="
  | O_Nequal-> "<>"
  | O_Greater -> ">"
  | O_Less  -> "<"
  | O_Lequal-> "<="
  | O_Gequal-> ">="
  (**)
  | O_If_jump   -> "ifb"
  | O_Jump      -> "jump"
  | O_Label     -> "label"
  | O_Jump_l    -> "jumpl"
  (**)
  | O_Call  -> "call"
  | O_Par   -> "par"
  | O_Ret   -> "ret"

let str_of_passmode = function
  | V   -> "V"
  | R   -> "R"
  | RET -> "RET"

let str_of_operand = function
  | Int i     -> string_of_int i
  | Char c    -> Printf.sprintf "'%s'" (Char.escaped c)
  | Str s     -> Printf.sprintf "%s" s
  | Boole b   -> (
    match b with 
    | true -> "true"
    | false -> "false"
      )
  | Invalid   -> "_INVAL_"
  | Label i   -> string_of_int i
  | Pass pm   -> str_of_passmode pm
  | Backpatch -> "*"
  | Empty     -> "-"
  | Result _  -> "$$"
  | Nil       -> "nil"
  | Pointer (e,_)   -> "[" ^ (Identifier.id_name e.entry_id) ^ "]" 
  | Entry e   -> Identifier.id_name e.entry_id
  (**)
  | Head  -> "head"
  | Tail  -> "tail"
  (*| NilQ  -> "nilq" (* doesn't exist! *)*)
  | Consp  -> "consp"
  | Consv  -> "consv"
  (**)
  | Newp   -> "newarrp"
  | Newv -> "newarrv"
  | Extend -> "extend"
  | Shrink -> "shrink"

(* Get size of I.operand_t *)
let sizeof_operand ?(sizeof = Types.sizeOfType) = function
  | Int _ -> Types.sizeOfType Types.TYPE_int
  | Char _ -> Types.sizeOfType Types.TYPE_char
  | Str s -> sizeof (Types.TYPE_array (Types.TYPE_char, String.length s + 1))(*Types.TYPE_int*) (* size of pointer *)
  | Boole _ -> Types.sizeOfType Types.TYPE_bool
  | Entry e -> begin
      match e.entry_info with 
      | ENTRY_variable v -> (sizeof v.variable_type)
      | ENTRY_parameter p -> (sizeof p.parameter_type)
      | ENTRY_temporary t -> (sizeof t.temporary_type)
      | _ -> (* never matched *)
          Error.internal "Request for size of non-variable, non-parameter, \
	    non-temporary entity."; 0
  end
  | Pointer (e, t) -> sizeof (*Types.TYPE_int*)  t 
  | Nil -> Types.sizeOfType Types.TYPE_int (* size of pointer *)
  | Result s -> Types.sizeOfType s 
  | _ -> Error.internal "sizeof_operand is called with non Int, Char, Entry, \
	    Pointer";0

(* Quad storage and manipulation *)
(* List of Quadraples *)
let quad_list = ref []

let add_quad q =
  quad_list := q :: !quad_list

let get_quads () =
  List.rev !quad_list

let print_quad ch q=
  Printf.fprintf ch "%d: %s, %s, %s, %s\n"
  q.label (str_of_operator q.opor) (str_of_operand q.opand1)
  (str_of_operand q.opand2) (str_of_operand q.opand3)

(* Print quads to file (Function with Currying!;) ).*)
let print_quads channel = 
  ignore (List.map (print_quad channel) (get_quads ()))

(* Replaces all 'Backpatch' operands in quads with labels in l to z 
 * (no of quad) 
 * XXX: There might be a bug here. I think that i consume list l. Do we need it
 * afterwards? *)
let backpatch (l:int list) (z:int) = 
  let patch (q:quad) (x:int) = q.opand3 <- Label x in
  let rec backpatch' l x =
    match l with
    | h::t -> 
        List.iter (fun qua -> 
          if (h==qua.label) then (patch qua x; backpatch' t x)
          else backpatch' t x) !quad_list
    | [] -> ()
  in 
  backpatch' l z

