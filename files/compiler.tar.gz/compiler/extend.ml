(*****************************************************************************
  * 
  * This file is part of Tonyc. 
  *
  * Tonyc is free software: you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation, either version 3 of the License, or
  * (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program.  If not, see <http://www.gnu.org/licenses/>.
  *
  *****************************************************************************)
open Pcaml
open Lexing

EXTEND
  expr: LEVEL "simple"
    [[ LIDENT "internal" ->
         let file = <:expr< $str:!input_file$ >>
         and line = <:expr< $int:string_of_int (Ploc.line_nb loc)$ >> in
         <:expr< internal_raw ($file$, $line$) >>
    |  UIDENT "Error"; "."; LIDENT "internal" ->
         let file = <:expr< $str:!input_file$ >>
         and line = <:expr< $int:string_of_int (Ploc.line_nb loc)$ >> in
         <:expr< Error.internal_raw ($file$, $line$) >>;
    ]];
END
