(* *****************************************************************************
 * -----------------------------
 * ---- Module Optimize --------
 * ----------------------------- 
 *
 * Functions for Intermediate code optimizations 
 * 
 * This file is part of Tonyc. 
 *
 * Tonyc is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
******************************************************************************)

open Intermediate
open Error


(* Auxiliary Functions for optimize *)
(* isJump q: 
 * Returns true if quad q is a Jump of any kind *)
let isJump (q:quad) = 
  match q.opor with
  | O_Equal| O_Nequal | O_Greater | O_Less | O_Lequal | O_Gequal 
  | O_If_jump | O_Jump -> true
  | _ -> false;;

(* isDirectJump q:
 * Returns true if quad q is a _direct_ Jump *)
let isDirectJump (q:quad) = 
  match q.opor with 
  | O_Jump -> true
  | _ -> false;;

(* isRelop q: 
 * Returns true if quad q is one of "=, <>, >=, <=, >, <" *)
let isRelop (q:quad) = 
  match q.opor with
  | O_Equal| O_Nequal | O_Greater | O_Less | O_Lequal | O_Gequal -> true
  | _ -> false

(* isBinop q: 
 * Returns true if quad q is one of "+, -, *, /, %" *)
let isBinop (q:quad) = 
  match q.opor with
  | O_Plus | O_Mult | O_Div | O_Mod -> true
 (* | O_Minus -> (* check if it is unary minus! *)  (*TODO kati epeze me auto
 kai to ebgala prostoparon *)
      match q.opand2 with
      |	Empty -> (* unary! *) false
      |	_ -> true *)
  | _ -> false

(* isAssign q:
 * Returns true if quad q is ":=" *)
let isAssign (q:quad) = 
  match q.opor with
  | O_Assign -> true
  | _ -> false

(* extractLabel q:
 * Extracts the Integer in Label position (useful in jumps) *)
let extractLabel (q:quad) = 
    match q.opand3 with
    | Label i -> i
    | _ -> error "No label in position of label!"; (-42);;

let isValid (q:quad) =
    match q.opand3 with
    |Invalid -> false
    | _     -> true;;

(* ----- Main optimization functions ------ *)
(* avoid_jump2jump quads: 
 * Propagation of Label in two consequent jumps. The first one can be a jump of 
 * any kind but the second one only a direct jump. This helps us avoid control  
 * flow! *) 
let avoid_jump2jump (i:int) (quads:quad list ref) = 
     let cur_quad = List.nth !quads i in
     if isValid cur_quad && isJump cur_quad then
       let tar_quad = List.nth !quads ((extractLabel cur_quad)-1) in
       if isValid tar_quad && isDirectJump tar_quad &&  ( (tar_quad.label -
       cur_quad.label) <  10) then 
         cur_quad.opand3 <- tar_quad.opand3
       else () (* skip *)
     else () (* skip *)

let avoid_jump2jump2 (quads:quad list ref) = 
    quads:=List.rev !quads;
    for i=1 to ((List.length !quads)-1) do
     let cur_quad = List.nth !quads i in
     if isValid cur_quad && isJump cur_quad then
       let tar_quad = List.nth !quads ((extractLabel cur_quad)-1) in
       if isValid tar_quad && isDirectJump tar_quad &&  (tar_quad.label-cur_quad.label)<10 then 
         cur_quad.opand3 <- tar_quad.opand3
       else () (* skip *)
     else () (* skip *)
    done;
    quads:=List.rev !quads
(* reverse_jumps quads:
 * Spot and reverse silly jumps to optimize out some quads. Transform 
 * "relop, x, y, t_label";"jump, -, -, f_label" to "not_relop, x, y, f_label"
 *)
let reverse_jumps (i:int) (quads:quad list ref) = 
   let rev_operator_list = 
       [ (O_Equal, O_Nequal);   (O_Nequal, O_Equal);
         (O_Less, O_Gequal);    (O_Gequal, O_Less);
         (O_Greater, O_Lequal); (O_Lequal, O_Greater)]
   in
   let revert_table = Hashtbl.create 6 in
   let () = List.iter (fun (op, rev_op) -> 
      Hashtbl.add revert_table op rev_op) rev_operator_list 
   in
   if (i>0) then
     let q1 = List.nth !quads (i-1) 
     and q2 = List.nth !quads (i) in
     if ((isValid q1) && (isValid q2)) then
       if (isRelop q1 && isDirectJump q2) then (* Can we optimize? *)
         if ((extractLabel q1) == q1.label +2) then (* We can optimize! *)
                 (* update relop quad *)
           let rev_op = Hashtbl.find revert_table q1.opor in
           q1.opor <- rev_op;
           q1.opand3 <- q2.opand3;
                 (* mark for removal *)
           q2.opand3 <- Invalid;   
         else ()
       else () (* skip *)
     else ()
   else ()

   
(* reverse_copy_propagation quads:
 * Transform "binop, x, y, $1";":=,$1,-,x||y" to "binop, x, y, x||y"
 *) 
let reverse_copy_propagation (i:int) (quads:quad list ref) = 
  if (i>0) then
    let q1 = List.nth !quads (i-1) 
    and q2 = List.nth !quads (i) in
    if ((isValid q1) && (isValid q2)) then
      if (isBinop q1 && isAssign q2) then (* Can we optimize? *)
        match q1.opand3,q2.opand1 with
          Entry a,Entry b-> if (a==b) then
            match q1.opand1,q2.opand3 with
              Entry x,Entry z -> if x==z then
                begin
                  q1.opand3 <- q2.opand3 ;
                  q2.opand3 <- Invalid
                end
              else ()
            | _ -> () ;
                match q1.opand2,q2.opand3 with
                  Entry x,Entry z -> if x==z then
                    begin
                      q1.opand3 <- q2.opand3;
                      q2.opand3 <- Invalid
                    end
                  else ()
                | _ -> () 
          else ()
        | _ -> ()
      else () (* skip *)
    else ()
  else ()

let simple_dead_code  (i:int)  (quads:quad list ref) =
  let q = List.nth !quads i in
  if (isValid q && (q.opor == O_If_jump)) then
    match q.opand1 with
      Boole true ->  
        let q_false_jump = List.nth !quads (i+1)
        in let  false_start = extractLabel q_false_jump
        in let q_true_end = List.nth !quads (false_start-1-1)
        in q.opor<-O_Jump; 
        q_false_jump.opand3<- Invalid;
        if (isValid q_true_end && q_true_end.opor = O_Jump) then   
        (* Exei false kommati- Isws o elegxow na min einai polu kalos--> Risky? *)
          let  false_end = extractLabel q_true_end in 
          for j=(false_start-1) to (false_end-1-1) do
            let q_fix = List.nth !quads j
            in q_fix.opand3 <- Invalid;
          done;
        else ()
    | Boole false ->  
        let true_start = extractLabel q in
        let q_false_jump = List.nth !quads (i+1) in
        let false_start = extractLabel q_false_jump in
        q.opor <- O_Jump;
        q.opand3 <- Label false_start;
        q_false_jump.opand3 <- Invalid;
        for j=(true_start-1) to (false_start-1-1) do
          let q_fix = List.nth !quads j
          in q_fix.opand3 <-Invalid;
        done;  
    | _ -> ()
  else ()
      
let optimize_all (quads:quad list ref) = 
  quads := List.rev !quads;
  for i=0 to ((List.length !quads)-1) do
    simple_dead_code i quads;
    reverse_copy_propagation i quads;
    reverse_jumps i quads
  done;
  quads := List.rev !quads;
  avoid_jump2jump2 quads;
  quads := List.filter isValid !quads
      
let optimize = optimize_all;;

(*TODO: Ligo mazema gia na trexoun ola mazi wste na ginetai mia fora to revert 
 * kai to filter. Mallon kai ligo mazema genika :-p *)
