(*****************************************************************************
 * 
 * This file is part of Tonyc. 
 *
 * Tonyc is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
******************************************************************************)
type id = string Hashcons.hash_consed

module Hid = Hashcons.Make (
  struct
    type t = string
    let equal = (=)
    let hash = Hashtbl.hash
  end
)

let id_make = Hashcons.register_hcons Hid.f ()
let id_name = Hashcons.hash_value

let pretty_id ppf id =
  Format.fprintf ppf "%s" (id_name id)
