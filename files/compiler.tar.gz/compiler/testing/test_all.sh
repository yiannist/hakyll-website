#!/bin/bash
# Name: test.all.sh
# Simple script for running all testcases..

PATH=".."
EXEC="tonyc"
CORRECT=0
ERROR=0
RESULT=0
echo "Starting..."

for x in *.tony
do
    echo "--------------------------------------------------------------"

    "${PATH}"/"${EXEC}" ${x}
    if [ ${?} -eq 0 ]; then
        CORRECT=$(($CORRECT+1))
    else
        ERROR=$(($ERROR+1))
    fi
done
echo "##############################################################"
echo "Succesful: ${CORRECT}"
echo "Errors : ${ERROR}"
echo "##############################################################"
