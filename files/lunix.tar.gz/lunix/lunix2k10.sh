#!/bin/bash
#############################################################################
 #
 # Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 # Contact: hydralis.r <at> gmail <dot> com, 
 #          yiannis.tsiouris <at> gmail <dot> com
 #
 # This file is part of Lunix.
 #
 # Lunix is free software: you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation, either version 3 of the License, or
 # (at your option) any later version.
 #
 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program.  If not, see <http://www.gnu.org/licenses/>.
 #############################################################################
module="lunix2k10"
device="lunix"
mode="664"
group="root"
INSMOD=`which insmod`
RMMOD=`which rmmod`

install() {
	#$INSMOD $* ./${module}.ko
	$INSMOD $* ./${module}.ko 
	major=`grep $device /proc/devices | awk '{ print $1}'`
	rm -f /dev/$device
	mknod /dev/$device c $major 0
}

remove() {
	$RMMOD $* $module
	rm -f /dev/$device
}

usage() {
	echo "Usage: `basename $0` (install|remove)"
}

case "$1" in
	install)
		shift 
		install $*
	;;

	remove)
		shift 
		remove $*
	;;
	
	*)
		usage
	;;
esac

exit 0
