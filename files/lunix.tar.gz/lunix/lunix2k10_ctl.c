/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralis.r <at> gmail <dot> com, 
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Lunix.
 *
 * Lunix is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include "lunix2k10.h"

void help(){
	printf(
		"usage: lunix_ctl <command>\n"
		"Commands:\n"
		"help                : this command\n"
		"getsize             : get the device size\n"
		"setsize <size>      : set the device size\n"
		"\n"
	);
}

int main(int argc, char **argv)
{
	int cmd=0;
	int fd;
	int ret=0;
	int arg_int;

	if ( argc < 2 ){
		help();
		exit(1);
	}

	if ( !strcmp(argv[1], "help") ){
		help();
		return 0;
	} else if ( !strcmp(argv[1], "getsize") ) {
		cmd = LUNIX_IOC_GETSIZE;
	} else if ( !strcmp(argv[1], "setsize") ){
		if ( argc < 2){
			help();
			exit(1);
		}
		cmd = LUNIX_IOC_SETSIZE;
		arg_int = atoi(argv[2]);
	} else {
		help();
		exit(1);
	}

	if ( (fd = open("/dev/lunix", O_RDWR)) < 0 ){
		perror("cant open file: /dev/lunix");
		exit(1);
	}

	switch ( cmd ){

		case LUNIX_IOC_GETSIZE:
			ret = ioctl(fd, cmd, &arg_int);
			if ( ret < 0) perror("ioctl");
			else printf("lunix buffer size: %d\n", arg_int);
			break;

		case LUNIX_IOC_SETSIZE:
			ret = ioctl(fd, cmd, &arg_int);
			if (ret < 0) perror("ioctl");
			else printf("lunix buffer size set to: %d\n", arg_int);
			break;

		default:
			break;
	}
	close(fd);

	return 0;
}
