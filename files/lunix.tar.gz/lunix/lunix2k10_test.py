#!/usr/bin/env python
#############################################################################
 #
 # This file is part of Lunix.
 #
 # Lunix is free software: you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation, either version 3 of the License, or
 # (at your option) any later version.
 #
 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program.  If not, see <http://www.gnu.org/licenses/>.
 #############################################################################

from os import system, SEEK_CUR, SEEK_END, SEEK_SET

device = "/dev/lunix"
ctl = "./lunix2k10_ctl"

def reset():
	system("%s setsize 0" % (ctl,))

def test0():
	reset()

	fw = open(device, 'w')
	fw.write("THIS IS A TEST")
	fw.close()

	fr = open(device)
	d = fr.read()
	fr.close()
	assert d == "THIS IS A TEST"

	fw = open(device, 'a+')
	fw.write("\nPIZZA")
	fw.close()

	fr = open(device)
	d = fr.read()
	fr.close()
	assert d == "THIS IS A TEST\nPIZZA"

def test1():
	reset()

	fw = open(device, 'w')
	fw.write("MEH BAH")
	fw.flush()

	fr = open(device, 'r')
	d = fr.read(3)
	assert d == "MEH"

	fr.seek(1, SEEK_CUR)
	d = fr.read()
	assert d == "BAH"

	fr.seek(-2,SEEK_CUR)
	d = fr.read()
	assert d == "AH"

	fw.seek(3, SEEK_SET)
	fw.write("_")
	fw.flush()

	fr.seek(1,SEEK_SET)
	d = fr.read()
	assert d == "EH_BAH"

	fr.close()
	fw.close()

if __name__ == '__main__':
	test1()
