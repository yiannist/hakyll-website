/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralis.r <at> gmail <dot> com, 
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Lunix.
 *
 * Lunix is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
#include <linux/init.h>
#include <linux/module.h>   //for THIS_MODULE macro
#include <linux/fs.h>       //for alloc_chrdev_region
#include <linux/kdev_t.h>   //for MAJOR, MINOR macros
#include "lunix2k10.h"

struct lunix_dev *device;
MODULE_LICENSE("GPL");

/*
 * Let us repeat that the buff argument to the read and write methods is a user-space
pointer. Therefore, it cannot be directly dereferenced by kernel code. There are a few
reasons for this restriction:
  • Depending on which architecture your driver is running on, and how the kernel
    was configured, the user-space pointer may not be valid while running in kernel
    mode at all. There may be no mapping for that address, or it could point to some
    other, random data.

  • Even if the pointer does mean the same thing in kernel space, user-space mem-
    ory is paged, and the memory in question might not be resident in RAM when
    the system call is made. Attempting to reference the user-space memory directly
    could generate a page fault, which is something that kernel code is not allowed
    to do. The result would be an “oops,” which would result in the death of the
    process that made the system call.

  • The pointer in question has been supplied by a user program, which could be
    buggy or malicious. If your driver ever blindly dereferences a user-supplied
    pointer, it provides an open doorway allowing a user-space program to access or
    overwrite memory anywhere in the system. If you do not wish to be responsible
    for compromising the security of your users’ systems, you cannot ever derefer-
    ence a user-space pointer directly.
*/
static int
lunix_open(struct inode *inode, struct file *file)
{
    struct lunix_dev *dev;
    
    printk(KERN_NOTICE "lunix: Read was called.");

    /*Code for acquiring the cdev struct of lunix_dev.
     *    container_of(pointer, container_type, container_field)
     *This macro takes a pointer to a field of type container_field, within a
     * structure of type container_type, and returns a pointer to the containing
     * structure. */
	dev = container_of(inode->i_cdev, struct lunix_dev, mydev);

	/* Save it for others to use it*/
	file->private_data = dev;
    
    if ( file->f_flags & O_TRUNC) {
        if (down_interruptible(&dev->sem))
            return -ERESTARTSYS;
        printk(KERN_NOTICE "lunix_open: with trunc");
        dev->size = 0;
        up(&dev->sem);
    }

    if (file->f_flags & O_APPEND) {
        printk(KERN_NOTICE "lunix_open: with append flag");
        file->f_pos = dev->size;
    }

	return 0;
}

/* Not every close system call causes the release method to be
 * invoked. Only the calls that actually release the device data structure 
 * invoke the method — hence its name. */
static int
lunix_release(struct inode *inode, struct file *file)
{
    //kfree(file->private_data);   //in next open we will take it back.

    printk(KERN_NOTICE "lunix: Release was called.");
	return 0;
}

static ssize_t
lunix_read(struct file *file, char __user *buff, size_t count, loff_t *ppos)
{
    struct lunix_dev *dev = file->private_data;
    ssize_t ret = 0;
    unsigned long size = dev->size;

    printk(KERN_NOTICE "lunix: Read was called.");

    if (down_interruptible(&dev->sem))
        return -ERESTARTSYS;     // Restart command

    if (*ppos >= size)
        goto out;                // Can't read anything
    if (*ppos + count >= size)
        count = size - *ppos;    // Can read only count bytes
   
    /* For writing into user-space, the method copy_to_user() is provided. It
     * takes three parameters. The first is the destination memory address in 
     * the process's address space. The second is the source pointer in 
     * kernel-space. Finally, the third argument is the size in bytes of the 
     * data to copy.*/
    if (copy_to_user(buff, &dev->data[*ppos], count)) {
        ret = -EFAULT;
        goto out;
    }

    *ppos += count;             // Upgrade Position
    ret = count;                // Return Successfully bytes read

out: 
    up(&dev->sem);
    return ret;
}

static ssize_t
lunix_write(struct file *file, const char __user *buff, size_t count, loff_t *ppos)
{
    struct lunix_dev *dev = file->private_data;
    ssize_t ret = -ENOMEM;
    unsigned long size = dev->size;

    printk(KERN_NOTICE "lunix: Write was called.");
    
    if (down_interruptible(&dev->sem))
        return -ERESTARTSYS;    // Restart command
    
    if (*ppos >= (MAX_BUFFER_SIZE-1))
        goto out;
    if ( (*ppos + count) >= (MAX_BUFFER_SIZE-1) )
        count = ((MAX_BUFFER_SIZE-1) - *ppos);

    if (copy_from_user(&dev->data[*ppos], buff, count)) {
        ret = -EFAULT;
        goto out;
    }

    *ppos += count;             // Upgrade Position
    
    if (size < *ppos)
        dev->size = *ppos;
    ret = count;                // Return Successfully bytes read

out: 
    up(&dev->sem);
    return ret;
}


loff_t
lunix_llseek(struct file *filp, loff_t offset, int whence)
{
    struct lunix_dev *dev = filp->private_data;
    loff_t pos;

    switch(whence){
        case SEEK_SET:          // Set to this offset
            pos = offset;
            break;
        case SEEK_CUR:          // Set with offset to current
            pos = filp->f_pos + offset;
            break;
        case SEEK_END:          // Set with offset to size of device..
            pos = dev->size + offset;
            break;
        default:
            return -EINVAL;
    }
    if (pos < 0) return -EINVAL;
    
    filp->f_pos = pos;
	return pos;
}

int
lunix_ioctl(struct inode *inode, struct file *filp,
            unsigned int cmd,  unsigned long arg)
{
	int ret=1;
    struct lunix_dev *dev;

    // -ENOTTY according to POSIX
    if (_IOC_TYPE(cmd) != LUNIX_IOC_MAGIC) return -ENOTTY;

    // Anapoda ta read/write giati einai apo pleura kernel..
    //  access_ok returns 1 for success and 0 for failure
    if (_IOC_DIR(cmd) & _IOC_READ)          //if cmd direction is read:
        ret = !access_ok(VERIFY_WRITE, (void __user *)arg, _IOC_SIZE(cmd));
    else if (_IOC_DIR(cmd) & _IOC_WRITE)
        ret = !access_ok(VERIFY_READ, (void __user *)arg, _IOC_SIZE(cmd));
    if (ret)
        return -EFAULT;

    ret = -EINVAL;
    switch (cmd){
        case LUNIX_IOC_GETSIZE:
            dev = filp->private_data;
            ret = __put_user(dev->size, (int __user *)arg);
            break;
        case LUNIX_IOC_SETSIZE:
            dev = filp->private_data;;
            ret = __get_user(dev->size, (int __user *)arg);
            break;
        default:
            ret = -ENOTTY;;
    }
    return ret;
}

static const struct file_operations lunix_fops = {
	.owner    = THIS_MODULE,
	.open     = lunix_open,
	.release  = lunix_release,
	.read     = lunix_read,
	.write    = lunix_write,
	.llseek   = lunix_llseek,
	.ioctl    = lunix_ioctl,
};

static void  lunix_exit(void)
{
    // Create dev in order to unregister it..
    dev_t dev = MKDEV(lunix_major, lunix_minor);
    // If device then dealocate it...
    if (device) {
        cdev_del(&device->mydev);
        kfree(device);
        printk(KERN_NOTICE "lunix: Freeing device \n");
    }        
   
    //Accessible only if alread registered
    unregister_chrdev_region(dev, 1);
   
    printk(KERN_ALERT "Goodbye");
}

static int __init lunix_init(void)
{
    int err;
    dev_t dev = 0;

    printk(KERN_NOTICE "lunix: I am in! :)");
    /* Get a major/minor numbers */
    err = alloc_chrdev_region(&dev, lunix_minor , 1, "lunix");
    if (err < 0) {
        printk(KERN_WARNING "lunix: Can't get major");
        return err;  // return because nothing to be undone
    }
    lunix_major = MAJOR(dev);
    lunix_minor = MINOR(dev);

    device = kmalloc(sizeof(struct lunix_dev), GFP_KERNEL);
    if (!device){
        err = -ENOMEM;
        goto err; //Wrong...you must undo what you have done
    }
    //Semaphore initialization to 1
    init_MUTEX(&device->sem);

    /* Device Allocation*/
    cdev_init(&device->mydev, &lunix_fops);    

    /* Device ready, "live", operations callable by kernel */
    err = cdev_add(&device->mydev, dev, 1);  
    if (err){
        printk (KERN_NOTICE "Error %d adding device", err);
        goto err;
    }

    return 0;

err:
    lunix_exit();
    return err;
    
}


module_init(lunix_init);
module_exit(lunix_exit);


