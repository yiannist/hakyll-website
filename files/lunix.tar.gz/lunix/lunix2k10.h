/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralis.r <at> gmail <dot> com, 
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Lunix.
 *
 * Lunix is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *****************************************************************************/
#ifndef LUNIX_
#define LUNIX__

#define MAX_BUFFER_SIZE 500
int lunix_major = 0;
int lunix_minor = 0;

#ifdef __KERNEL__
#include <linux/cdev.h>
struct lunix_dev {
    char data[MAX_BUFFER_SIZE];
    unsigned long size;
    struct semaphore sem;    
    struct cdev mydev;
};
#endif

#include <linux/ioctl.h>
#define LUNIX_IOC_MAGIC 'k'
#define LUNIX_IOC_GETSIZE   _IOW(LUNIX_IOC_MAGIC, 0, int *)
#define LUNIX_IOC_SETSIZE   _IOR(LUNIX_IOC_MAGIC, 1, int *)

#endif /* LUNIX__ */
