{------------------------------------------------------------------------------
 -
 - Implementation of Hindley-Milner Type Inference algorithm for simply typed 
 - λ-calculus.
 -
 - Author: Yiannis Tsiouris (yiannis_t)
 - Contact: yiannis.tsiouris <at> gmail <dot> com
 -
 - This program is free software: you can redistribute it and/or modify
 - it under the terms of the GNU General Public License as published by
 - the Free Software Foundation, either version 3 of the License, or
 - (at your option) any later version.
 -
 - This program is distributed in the hope that it will be useful,
 - but WITHOUT ANY WARRANTY; without even the implied warranty of
 - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 - GNU General Public License for more details.
 -
 - You should have received a copy of the GNU General Public License
 - along with this program.  If not, see <http://www.gnu.org/licenses/>.
 -
 ------------------------------------------------------------------------------}

import Char
import IO
import Data.Maybe
import qualified Data.IntMap as IM

data Type  =  Tvar Int | Tfun Type Type                        deriving Eq
data Expr  =  Evar String | Eabs String Expr | Eapp Expr Expr  deriving Eq

-- Pretty printing of expressions

always = True    -- False omits parentheses whenever possible

instance Show Expr where
  showsPrec p (Evar x) = (x ++)
  showsPrec p (Eabs x e) =
    showParen (always || p > 0) ((("\\" ++ x ++ ". ") ++) . showsPrec 0 e)
  showsPrec p (Eapp e1 e2) =
    showParen (always || p > 1) (showsPrec 1 e1 . (" " ++) . showsPrec 2 e2)

-- Parsing of expressions

instance Read Expr where
  readsPrec _ s =
    readParen True (\s ->
      [(Eabs x e, r)    |  ("\\", t1)  <-  lex s,
                           (x, t2)     <-  lex t1, isVar x,
                           (".", t3)   <-  lex t2,
                           (e, r)      <-  readsPrec 0 t3] ++
      [(Eapp e1 e2, r)  |  (e1, t)     <-  readsPrec 0 s,
                           (e2, r)     <-  readsPrec 0 t]) s ++
    [(Evar x, r) | (x, r) <- lex s, isVar x]
      where isVar x = isAlpha (head x) && all isAlphaNum x

-- Pretty printing of types

instance Show Type where
  showsPrec p (Tvar alpha) = ("@" ++) . showsPrec 0 alpha
  showsPrec p (Tfun sigma tau) =
    showParen (p > 0) (showsPrec 1 sigma . (" -> " ++) . showsPrec 0 tau)


-- Read one Expr
readOne :: IO Expr
readOne  =  do  s <- getLine
                return (read s :: Expr)


-- Repeat n-times monad m
count n m  =  sequence $ take n $ repeat m

type Context = [(Expr, Type)]     -- Γ :- e : τ
type Constraint = (Type, Type)    -- C = {τ1 = τ2}
type Id = Int                     -- @i

-- Extract Type of Expr e in Context gamma
getType :: Context -> Expr -> Maybe Type
getType [] e = Nothing
getType ((e1,t1):ts) e | (e1 == e) = Just t1
                       | otherwise = getType ts e

-- Type checking algorithm (Wikipedia: f function)
type_check :: Id -> Context -> Expr -> (Id, [Constraint], Maybe Type)
type_check id gamma e = do 
  case e of 
    Evar _ -> (id, [], getType gamma e)
    Eabs x e1 -> (id', c, t)
      where fresh_a = Tvar id
            (id', c, ret) = type_check (id+1) ((Evar x, fresh_a):gamma) e1 
            t = if isNothing ret 
                then Nothing
                else let t' = fromJust ret 
                     in
                      Just (Tfun fresh_a t')
    Eapp e1 e2 -> (id'', c, t)
      where (id', c1, t1) = type_check (id+1) gamma e1
            (id'', c2, t2) = type_check (id') gamma e2
            (c, t) = if (isNothing t1 || isNothing t2)
                     then ([], Nothing)
                     else let t1' = fromJust t1
                              t2' = fromJust t2
                              fresh_a = Tvar id
                          in
                           ((t1', Tfun t2' fresh_a) : c1 ++ c2, Just fresh_a)
    
-- Type t1 `existsIn` Type t2
existsIn :: Type -> Type -> Bool
existsIn t1 t2@(Tvar _) = (t1 == t2)
existsIn t1 t2@(Tfun t2' t2'') = (t1 == t2) || t1 `existsIn` t2' 
                                 || t1 `existsIn` t2''

-- Replace Type a with Type t1 in Type t (a -> t1 in t)
substInT :: (Type, Type) -> Type -> Type
substInT (a,t1) t@(Tvar _) = 
  if a == t then t1 else t
substInT (a,t1) t@(Tfun t' t'') = 
  Tfun ((a,t1) `substInT` t') ((a,t1) `substInT` t'')

-- Make substitution [α -> t] in Constraint set.
substCs :: (Type, Type) -> [Constraint] -> [Constraint]
substCs (a,t) c = map (substInC (a,t)) c
  where 
    -- Make substitution [α -> t] in Constraint rule.
    substInC :: (Type, Type) -> Constraint -> Constraint
    substInC (a,t) (c1,c2) = ((a,t) `substInT` c1, (a,t) `substInT` c2)
  
-- Hindley-Milner: compute Constraint set (Wikipedia: u function)
unify :: [Constraint] -> Maybe [Constraint]
unify cs = unify' cs []
  where unify' [] l = Just l
        unify' ((t1,t2):ts) l           | (t1 == t2) = unify' ts l
        unify' ((t1@(Tvar _), t2):ts) l | not(t1 `existsIn` t2) = unify' ts' l'
          where l' = (t1,t2):(substCs (t1,t2) l)
                ts' = substCs (t1,t2) ts
        unify' ((t1, t2@(Tvar _)):ts) l | not(t2 `existsIn` t1) = unify' ts' l'
          where l' = (t2,t1):(substCs (t2,t1) l)
                ts' = substCs (t2,t1) ts
        unify' ((t1@(Tfun t11 t12), t2@(Tfun t21 t22)):ts) l = unify' ts' l
          where ts' = (t11,t21):(t12,t22):ts
        unify' _ _ = Nothing
                                
-- Apply substitution (list of constraints) in final result.
applySubst :: [Constraint] -> Type -> Type
applySubst [] t = t
applySubst ((t1,t2):ts) t = applySubst (substCs (t1,t2) ts) (substInT (t1,t2) t) 

-- Allocate type variable numbers in `lexicograph` order.
fix_numbers :: Type -> Type
fix_numbers t = let (t', _, _) = fix_numbers' t imap 0 in t'
  where imap = IM.empty
        fix_numbers' :: Type -> IM.IntMap Int -> Int -> (Type, IM.IntMap Int, Int)
        fix_numbers' (Tvar i)  m id = case IM.lookup i m of
          Just t -> (Tvar t, m, id)
          Nothing -> (Tvar id, IM.insert i id m, id+1) 
        fix_numbers' (Tfun t1 t2) m id = (Tfun t1' t2', m'', id'')
          where (t1', m', id') = fix_numbers' t1 m id
                (t2', m'', id'') = fix_numbers' t2 m' id'

-- Infer type of Expr (and print). 
type_inf :: Expr -> IO ()
type_inf e =  do 
  let (_, c, t) = type_check 0 [] e  -- Extract constraint set.
      subst = unify c                -- Solve the equations/constraints.
  if isNothing t || isNothing subst
    then putStr "type error\n"
    else let s = fromJust subst
             t' = fromJust t
             res = applySubst s t'
             res' = fix_numbers res
         in
          print res'
  
-- Main
main     =  do  n <- readLn :: IO Int
                l <- count n readOne :: IO [Expr]
                mapM_ type_inf l

