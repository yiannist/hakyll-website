/******************************************************************************
 *
 * Travelling Salesman Problem (TSP) solution implemented in C.

 * Author: Yiannis Tsiouris (yiannis_t)
 * Contact: yiannis.tsiouris <at> gmail <dot> org
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
//int __builtin_popcount (unsigned int x); GCC specific instruction to count 1s

//My linked list
typedef struct list_el llist;
struct list_el{
    int val;
    struct llist *next;
};

/*  reads an array with integers from a file
    FORMAT:
    [#cities]
    a[0][0]
    a[1][0]_a[1][1]
    ...   */
int ** readGraph(char *filename, int *n)
{
    FILE *fp;
    int ** G, i, j;

    if ((fp = fopen(filename, "r")) == NULL)
	{
	    fprintf(stderr, "Unable to open %s!\n", filename);
	    exit(1);
	}

    fscanf(fp, "%d\n", n);

    if ((G = (int**) malloc((*n) * sizeof(int*))) == NULL)
	{
	    fprintf(stderr, "Out of memory!\n");
	    exit(1);
	}
    for(i = 0; i < *n; i++)
	{
	    G[i] = (int*) malloc((*n) * sizeof(int));
	    if(G[i] == NULL)
		{
		    fprintf(stderr, "out of memory\n");
		    exit(0);
		}
	}

    for (i = 0; i < *n; i++)
        for (j = 0; j <= i; j++)
	    {
		fscanf(fp,"%d",&G[i][j]);
		G[j][i] = G[i][j] ;
	    }

    fclose(fp);
    return(G);
} 

/*Exponation by squaring*/
int fastpow(int x, int n)
{ 
    long int result = 1;

    while (n > 0) {
        if (n & 1)  /* n is odd, bitwise test */
            result *= x;
        x *= x;
        n /= 2;     /* integer division, rounds down */
    }
    //printf("%ld\n",result);
    return result;
}

void TSP(int ** G, int n)
{
    int no_sunola = fastpow(2,n);
    llist *sunola[n];
    int i,j,pos,through_node;
    llist *node;
    int set,set_noj,copy_set,copy_set_noj,mask,nod,fullset;
    int cost,tempcost;

    short int **L = malloc(n * sizeof(short int *));    //Shortest Distance
    short int **J = malloc(n * sizeof(short int *));    //Next Node
    for(i = 0; i < n; i++){
        L[i] = malloc(no_sunola * sizeof(short int));  
        J[i] = malloc(no_sunola * sizeof(short int));   
    }

    //Initialize array of lists
    for( i=0; i<n; i++){
        sunola[i] = (llist *) malloc(sizeof(llist));
        if (sunola[i]==NULL){
            printf("Memory issues!\n");
            exit(-1);
        }else
            sunola[i]->next = NULL;
    };
    for( i=1; i<no_sunola; i++){
        if( !(i&1) ){                           //Don't want subsets with 1
            pos = __builtin_popcount(i);
            node = (llist *) malloc(sizeof(llist));
            if (node == NULL){
                printf("Memory issues2!\n");
                exit(-1);
            }
            node->val = i;                      //Built list of sets with cardinality pos
            node->next = sunola[pos];
            sunola[pos] = node;
        }
    }

     //Initialize L table
    for (i=0; i<n; i++)                         // 1..(n-1) = {2,3,4,5}
	L[i][0] = G[i][0];                          // 0 == n1 !

    for (pos=1; pos<n-1; pos++){  
        node = sunola[pos];         
        while( node->next != NULL){
            set = node->val;                    //pick a set that |S|=k, e.g: 011010
            for(i=1; i<n;i++){                  //Choose a node not in S
                mask = 1 << i;
                if (( set & mask) == 0) {       //n(i+1) not in S
                                                //e.g: 011010
                                                //     000100
                                                //     ------
                                                //     000000
                    cost = INT_MAX;
                    //Iterate nodes in S
                    copy_set = set;
                    j = 1;
                    while (copy_set != 0){
                        if ((copy_set  & 1 ) != 0){              // nj in Set
                            set_noj = set & (~(1<<(j-1)));       // eg: 011010
                                                                 //     001000
                                                                 //     ------
                                                                 //     001000
                            tempcost = G[i][j-1] + L[j-1][set_noj];
                            if (tempcost < cost){
                                cost = tempcost;
                                through_node = j;
                            }
                            L[i][set] = cost;                   //Find min cost through set
                            J[i][set] = through_node;           //Set next node through set
                        }
                        j++;
                        copy_set = copy_set >> 1;
                    }
                }
            };
            node = node->next;                  //Pick another set with same cardinality
        };
        node = sunola[pos];                     //Free mem from list with previous cardinality
        while (node->next != NULL){
            sunola[pos] = sunola[pos]->next;
            free(node);
            node = sunola[pos];
        };
        free(node);
    }

    cost = INT_MAX;                             //Find cost from i through set {2,3,4,...,n}\i
    for(i=1; i<n; i++){
        nod = ((1<<i) | 1);                     //nod = {1,n(i+1)}, e.g: 000101
        set_noj = ~nod;                         //e.g:111111
                                                //    111010 (000101) 
        tempcost = G[0][i] + L[i][set_noj];
        if (tempcost < cost){
            cost = tempcost;
            through_node = i+1;
        }
    }

    fullset = ((no_sunola-1) & ~(1));           //Find final cost through set {2,3,...,n}
    L[0][fullset] = cost; 
    J[0][fullset] = through_node;
    
    /* output format e.g.
       550
       1 3 5 2 4 1
    */
    printf("ROUTE: %d\n",L[0][fullset]);
    printf("1 ");
    through_node = 0;                           //through_node has next stop
                                                //fullset has {2,3,4,...,n}
    while (fullset != 0){                                       //While we have unvisited nodes
        printf("%d ", J[through_node][fullset]);                //Print next through_node
        through_node = J[through_node][fullset]-1;              //-fix for C array index
        fullset = fullset & ~(1<<(through_node));               //Remove through_node from set
    }
    printf("1\n");
}

void printMatrix(int **G, int n)
{ 
    int i,j;
    for (i = 0; i < n; i++){
        for (j = 0; j < n; j++)
            printf("%4d ",G[i][j]);
        printf("\n");
    }
}

int main(int argc, char *argv[])
{
    int n; // number of cities
    int **G;

    if (argc != 2)
	{
	    fprintf(stderr, "Usage: %s filename!\n", argv[0]);
	    exit(1);
	}

    G = readGraph(argv[1], &n);
    //printMatrix(G, n);
    TSP(G,n);

    return 0;
}
