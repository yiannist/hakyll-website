/******************************************************************************
* This file is part of Pydbms software.
*
* Pydbms is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
******************************************************************************/
drop table if exists institution cascade;
drop table if exists school cascade;
drop table if exists researcher cascade;
drop table if exists degree cascade;
drop table if exists institution_phone cascade;
drop table if exists school_phone cascade;
drop table if exists dep cascade;
drop table if exists lab_researcher cascade;
drop table if exists occupy cascade;
drop table if exists suggests cascade;
drop table if exists works_in cascade;
drop table if exists published cascade;
drop table if exists sponsor cascade;
drop table if exists funds cascade;
drop table if exists project cascade;
drop table if exists publication cascade;

drop type if exists location cascade;
drop type if exists address cascade;
drop type if exists fullname cascade;
drop domain if exists year cascade;

CREATE TYPE location AS (
    country varchar(50) ,
    city varchar(50)
);
CREATE TYPE address AS (
    street varchar(50),
    num integer,
    zipcode varchar(10)
);

CREATE TYPE fullname AS (
    first varchar(20),
    last varchar(20)
);

CREATE DOMAIN year AS integer 
    CHECK (VALUE<=2010 AND VALUE>1800);

CREATE TABLE institution (
    inscode serial PRIMARY KEY,
    name varchar(50) NOT NULL,
    yfounded year,
    site varchar(60),
    loc location NOT NULL
--    addr address
);


CREATE TABLE institution_phone (
    inscode integer REFERENCES institution(inscode) ON DELETE CASCADE ON UPDATE CASCADE,
    phone varchar(20) NOT NULL,
    PRIMARY KEY(inscode,phone)
);

CREATE TABLE researcher (
    rescode serial PRIMARY KEY,
    name fullname NOT NULL,
    phone varchar(20),
    site varchar(60),
    email varchar(60),
    loc location NOT NULL,
    addr address
);


CREATE TABLE dep (
    rescode integer PRIMARY KEY REFERENCES researcher(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    rank varchar(20) -- Maybe needs contraint
);


CREATE TABLE school (
    schcode serial UNIQUE NOT NULL,
    inscode integer REFERENCES institution(inscode) ON DELETE CASCADE ON UPDATE CASCADE,
    name varchar(50) NOT NULL,
    head integer REFERENCES dep(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    yelect year,
    yfounded year,
    PRIMARY KEY(schcode,inscode)
);

    
CREATE TABLE school_phone (
    schcode integer REFERENCES school(schcode) ON DELETE CASCADE ON UPDATE CASCADE,
    phone varchar(20) NOT NULL,
    PRIMARY KEY(schcode,phone)
);

CREATE TABLE degree (
    rescode integer REFERENCES researcher(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    schcode integer REFERENCES school(schcode) ON DELETE CASCADE ON UPDATE CASCADE,
    profcode integer REFERENCES dep(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    title varchar(50) NOT NULL,
    grade numeric(4,2) NOT NULL, 
    year year,
    PRIMARY KEY(rescode,schcode,profcode,title),
    CHECK (grade>=5 AND grade<=10)
);
    
CREATE TABLE lab_researcher (
    rescode integer PRIMARY KEY REFERENCES researcher(rescode) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE occupy (
    schcode integer REFERENCES school(schcode) ON DELETE CASCADE ON UPDATE CASCADE,
    rescode integer REFERENCES researcher(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    started date NOT NULL,
    ended date NOT NULL,
    sallary integer NOT NULL,
    rank varchar(20) NOT NULL, --xreiazetai elegxo sto api
    PRIMARY KEY(schcode,rescode,started),
    CHECK (started<ended)
);

CREATE TABLE sponsor (
    sponcode serial PRIMARY KEY,
    name varchar(50) NOT NULL,
    sptype varchar(50)
);

CREATE TABLE project (
    projcode serial PRIMARY KEY,
    title varchar(100) NOT NULL,
    started date,
    ended date,
    check (started < ended)
);

CREATE TABLE funds (
    sponcode integer REFERENCES sponsor(sponcode) ON DELETE CASCADE ON UPDATE CASCADE,
    projcode integer REFERENCES project(projcode) ON DELETE CASCADE ON UPDATE CASCADE,
    started date NOT NULL,
    amount integer NOT NULL,
    ended date,
    PRIMARY KEY(sponcode, projcode, started)
);

CREATE TABLE publication (
    pubcode serial PRIMARY KEY,
    title varchar(50) NOT NULL,
    magaz varchar(50),
    date_publ date NOT NULL,
    refers integer
);

CREATE TABLE suggests (
    sponcode integer REFERENCES sponsor(sponcode) ON DELETE CASCADE ON UPDATE CASCADE,
    rescode integer REFERENCES researcher(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    code serial UNIQUE NOT NULL,
    reason varchar(200) NOT NULL,
    amount integer NOT NULL,
    state varchar(50) NOT NULL,
    PRIMARY KEY(sponcode,rescode,code)
);

CREATE TABLE works_in (
    rescode integer REFERENCES researcher(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    projcode integer REFERENCES project(projcode) ON DELETE CASCADE ON UPDATE CASCADE,
    started date NOT NULL,
    sallary integer NOT NULL,
    ended date,
    PRIMARY KEY (rescode, projcode, started)
);

CREATE TABLE published (
    rescode integer REFERENCES researcher(rescode) ON DELETE CASCADE ON UPDATE CASCADE,
    pubcode integer REFERENCES publication(pubcode) ON DELETE CASCADE ON UPDATE CASCADE,
    PRIMARY KEY (rescode,pubcode)
);



CREATE VIEW institution_schools as 
    select ins.inscode, ins.name as ins_name ,sch.schcode,sch.name as sch_name 
        from institution as ins 
                join 
            school as sch
                on (ins.inscode=sch.inscode);

CREATE VIEW  school_occupys as 
select sch.schcode, sch.name, occ.rescode, occ.sallary,occ.rank,occ.started,occ.ended 
        from school as sch 
                join
            occupy as occ 
                on sch.schcode=occ.schcode;

CREATE VIEW sponsor_funds_project as
    select spon_occ.sponcode,spon_occ.name,spon_occ.amount,proj.title 
        from (select sponsor.sponcode,sponsor.name,funds.projcode,funds.amount from sponsor join funds on sponsor.sponcode=funds.sponcode) as spon_occ 
            natural join 
        project as proj;

CREATE function printname(fullname) returns varchar
      as $$ select ($1).first||' '||($1).last $$ language sql;

CREATE function printlocation(location) returns varchar
    as $$ select ($1).country||' '||($1).city $$ language sql;
