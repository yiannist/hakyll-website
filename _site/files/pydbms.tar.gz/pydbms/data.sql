/******************************************************************************
* This file is part of Pydbms software.
*
* Pydbms is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
******************************************************************************/

--Instituion
insert into institution values (default,'National Technological University of Athens',1873,'www.ntua.gr',('Greece','Athens'));
insert into institution values (default,'Aristotle University of Thessaloniki',1925,'eng.auth.gr',('Greece','Thessaloniki'));
insert into institution values (default,'Massachusetts Institute of Technology',1922,'web.mit.edu',('USA','Massachusett'));
insert into institution values (default,'Harvard University',1959,'www.harvard.edu',('USA','Cambridge'));
insert into institution values (default,'Oxford University', 1868,NULL,('Oxford', 'England'));
insert into institution values (default,'Cambridge University', 1901, NULL,('Cambridge', 'England'));

--Researcher
insert into researcher values (default,('Dimitris','Fotakis'),'6947732898','www.fotakis.gr','fotakis@ntua.gr',('Greece','Athens'));
insert into researcher values (default,('Kostis','Sagwnas'),'69532948576','www.sagonas.gr','sagonas@ntua.gr',('Sweden','Stockholm'));
insert into researcher values (default,('Timos','Sellis'),'210-3209232','www.sellis.gr','timosselis@ntua.gr',('Greece','Athens'));
insert into researcher values (default,('Ioannis','Basileiou'),NULL,NULL,'ihavanoemail@email.com',('Greece','Thessaloniki'));
insert into researcher values (default,('Charles','Leiserson'),'6928374920','www.leiserson.com',NULL,('USA','Massachusett'));
insert into researcher values (default,('Ronnald','Rivest'),'0030-33-39320',NULL,NULL,('USA','Massachusett'));
insert into researcher values (default,('Thomas','Cormen'),NULL,'www.irule.com',NULL,('Italy','Roma'));
insert into researcher values (default,('John','Pappas'),NULL,'www.whoami.com',NULL,('Spain','Barcelona'));
insert into researcher values (default,('Paris','Siminelakis'),'2101020110','www.paris.gr',NULL, ('Greece','Ioannina'));
insert into researcher values (default,('Manu','Chao'), NULL, NULL,NULL,('Paris','France'));
insert into researcher values (default,('Spuros','Pagourtzis'),'6943456789','www.pagouri.gr','pagouris@ntua.gr',('Greece','Athens'));
insert into researcher values (default,('John','Tsitsiklis'),'6947754898','tsitsiklis.mit.edu','tsitsiklis@mit.edu',('USA','Massachusett'));
insert into researcher values (default,('Dimitris','Bertsekas'),'6947712398','bertsekas.mit.edu','bertsekas@mit.edu',('USA','Massachusett'));
insert into researcher values (default,('Dimitris','Bertsimas'),'6923456758','bertsimas.mit.edu','bertsimas@mit.edu',('USA','Massachusett'));
insert into researcher values (default,('Christos','Papadimitriou'),'6923452158','papadimitriou.berkeley.edu','papadimitriou@berkeley.edu',('USA','California'));
insert into researcher values (default,('Kostas','Daskalakis'),'6992456758','daskalakis.mit.edu','daskalakis@mit.edu',('USA','Massachusett'));
insert into researcher values (default,('Christos','Faloutsos'),'6987456758','faloutsos.gatech.edu','faloutsos@gatech.edu',('USA','Georgia'));
insert into researcher values (default,('Sonfotakis','Zaxos'),'6934256758','fotakis4tw.com','sonfoatakis@ntua.gr',('Greece','Athens'));
insert into researcher values (default,('Manos','Dhmou'),'6931234758','manosdimou.xxx.com','manosdimou@gmail.com',('Greece','Athens'));
insert into researcher values (default,('Georgia','Tsiouri'),'6953634758','papabill4.3v3r.com','gsae@gmail.com',('Greece','Athens'));
insert into researcher values (default,('John','Tsiouris'),'6959874758','linux.hacker.os','gtsiour@gmail.com',('Greece','Athens'));
insert into researcher values (default,('Isaak','Newton'),NULL,NULL,NULL,('Cambridge','England'));
insert into researcher values (default,('George','Boole'),NULL,NULL,NULL,('Cambridge','England'));
insert into researcher values (default,('Albert','Frege'),NULL,NULL,NULL,('Oxford','England'));
insert into researcher values (default,('Alan','Turing'),NULL,NULL,NULL,('USA','Cambridge'));
insert into researcher values (default,('Erick','Tarjan'),NULL,NULL,NULL,('USA','Cambridge'));
insert into researcher values (default,('Van','Hohenhein'),NULL,NULL,NULL,('England','Oxford'));
insert into researcher values (default,('Petros','Maragos'),'6959324758','maragos.cvsp.ntua.gr','pmaragos@cvsp.ntua.gr',('Greece','Athens'));
insert into researcher values (default,('Bill','Papavasillopoulos'),'6769324758','pbill.control.ece.ntua.gr','pbill@control.ece.ntua.gr',('Greece','Athens'));
insert into researcher values (default,('Elder','Euler'),NULL,NULL,NULL,('Greece','Thessaloniki'));
insert into researcher values (default,('Graham','Bell'),NULL,NULL,NULL,('Greece','Thessaloniki'));
insert into researcher values (default,('Albert','Einstein'),NULL,NULL,NULL,('Greece','Thessaloniki'));
insert into researcher values (default,('Alan','Church'),NULL,NULL,NULL,('USA','Cambridge'));
insert into researcher values (default,('Robert','Knuth'),NULL,NULL,NULL,('USA','Cambridge'));
insert into researcher values (default,('Dirk','Lohness'),NULL,NULL,NULL,('USA','Cambridge'));





--Dep
insert into dep values(1,'Assistant Professor');
insert into dep values(2,'Professor');
insert into dep values(3,'Professor');
insert into dep values(4,'Professor');
insert into dep values(5,'Professor');
insert into dep values(6,'Lecturer');
insert into dep values(7,'Professor');
insert into dep values(8,'Lecturer');
insert into dep values(9,'Assistant Professor');
insert into dep values(10,'Professor');
insert into dep values(11,'Professor');
insert into dep values(12,'Professor');
insert into dep values(13,'Professor');
insert into dep values(14,'Lecturer');
insert into dep values(15,'Professor');
insert into dep values(16,'Lecturer');
insert into dep values(28,'Assistant Professor');
insert into dep values(29,'Professor');
insert into dep values(30,'Professor');
insert into dep values(31,'Professor');
insert into dep values(32,'Professor');
insert into dep values(33,'Lecturer');
insert into dep values(34,'Professor');
insert into dep values(35,'Lecturer');

--School
insert into school values(1,1,'School of Electrical and Computer Engineering',2,2007,1992);
insert into school values(2,1,'School of Architecture',2,2006,1964);
insert into school values(3,1,'School of Architecture',2,2007,1962);
insert into school values(4,2,'School of Civil Engineering',4,2008,1966);
insert into school values(5,2,'School of Electrical and Computer Engineering',4,2008,1968);
insert into school values(6,3,'School of Architecture',5,2008,1966);
insert into school values(7,3,'School of Electrical and Computer Engineering',5,2004,1954);
insert into school values(8,4,'School of Electrical and Computer Engineering',7,2003,1957);
insert into school values(9,4,'School of Architecture',7,2009,1954);
insert into school values(10,5,'School of Electrical and Computer Engineering',33,2007,1992);
insert into school values(11,5,'School of Operations Research',34,2006,1964);
insert into school values(12,6,'School of Physics',10,2007,1962);
--Instituion_Phone
insert into institution_phone values(1,'210-8034737');
insert into institution_phone values(1,'210-5460232');
insert into institution_phone values(1,'218-3020392');
insert into institution_phone values(2,'0032-302002');
insert into institution_phone values(3,'0709-030202');
insert into institution_phone values(4,'0045-388923');
insert into institution_phone values(4,'0045-271631');

--School_Phone
insert into school_phone values(1,'210-4324332');
insert into school_phone values(1,'210-2372393');
insert into school_phone values(2,'210-2382389');
insert into school_phone values(2,'210-4324032');
insert into school_phone values(3,'210-4328843');
insert into school_phone values(4,'0030-320902');
insert into school_phone values(4,'0030-302023');
insert into school_phone values(5,'0032-942039');
insert into school_phone values(6,'0043-299323');
insert into school_phone values(7,'0040-320290');
insert into school_phone values(8,'0020-300203');
insert into school_phone values(8,'0020-320203');
insert into school_phone values(9,'0102-393203');

--Degree
insert into degree values(1,3,5,'Graduate',10,1996);
insert into degree values(1,3,5,'Master',9,1996);
insert into degree values(2,3,5,'Graduate',8.32,1997);
insert into degree values(2,4,5,'Master',7.5,1998);
insert into degree values(3,4,3,'Graduate',9.5,2000);
insert into degree values(3,3,2,'Master',9.21,1857);
insert into degree values(4,3,5,'Graduate',5.32,1992);
insert into degree values(5,1,2,'Graduate',7.01,1988);
insert into degree values(5,1,2,'Master',8.15,1988);
insert into degree values(6,2,3,'Graduate',8.5,1999);
insert into degree values(6,2,4,'Master',6.42,2002);
insert into degree values(9,5,1,'Graduate',9.145,2010);
insert into degree values(10,8,8,'Master',5.53,1997);
insert into degree values(12,7,13,'Graduate',10,1996);
insert into degree values(12,7,13,'Master',9,1996);
insert into degree values(13,7,14,'Graduate',8.32,1997);
insert into degree values(13,7,14,'Master',7.5,1998);
insert into degree values(33,9,11,'Graduate',9.5,2000);
insert into degree values(33,9,11,'Master',9.21,1857);
insert into degree values(22,1,14,'Graduate',5.32,1992);
insert into degree values(28,11,33,'Graduate',7.01,1988);
insert into degree values(5,2,7,'Master',8.15,1988);
insert into degree values(2,9,10,'Graduate',8.5,1999);
insert into degree values(12,7,13,'PhD',5.12,1998);
insert into degree values(1,2,3,'Graduate',9.145,2010);
insert into degree values(4,7,12,'Master',5.53,1997);

--Occupy
insert into occupy values(1,1,'2000-05-30','2004-02-11',1000,'Assistant Professor');
insert into occupy values(1,1,'2005-08-24','2012-03-25',2000,'Professor');
insert into occupy values(2,3,'1965-03-21','1979-04-16',1500,'Assistant Professor');
insert into occupy values(3,3,'1980-04-20','2010-01-16',3000,'Professor');
insert into occupy values(3,2,'1995-06-15','2005-05-18',1800,'Professor');
insert into occupy values(4,4,'1990-11-16','2007-07-20',1700,'Assistant Professor');
insert into occupy values(5,5,'1992-12-18','2000-08-22',3500,'Professor');
insert into occupy values(6,6,'2000-10-19','2020-11-23',4000,'Professor');
insert into occupy values(7,7,'2001-03-22','2009-12-25',500,'Lecturer');
insert into occupy values(8,8,'2003-02-23','2009-05-07',3600,'Professor');
insert into occupy values(9,9,'2000-05-30','2004-02-11',3000,'Assistant Professor');
insert into occupy values(10,10,'2005-08-24','2012-03-25',4000,'Professor');
insert into occupy values(11,11,'1965-03-21','1979-04-16',1200,'Assistant Professor');
insert into occupy values(6,12,'1980-04-20','2010-01-16',3000,'Professor');
insert into occupy values(1,13,'1995-06-15','2005-05-18',3000,'Professor');
insert into occupy values(2,14,'1990-11-16','2007-07-20',1700,'Assistant Professor');
insert into occupy values(3,15,'1992-12-18','2000-08-22',3500,'Professor');
insert into occupy values(4,16,'2000-10-19','2020-11-23',4000,'Professor');
insert into occupy values(5,17,'2001-03-22','2009-12-25',1100,'Lecturer');
insert into occupy values(6,18,'2003-02-23','2009-05-07',3600,'Professor');
insert into occupy values(7,19,'2000-05-30','2004-02-11',1000,'Assistant Professor');
insert into occupy values(8,20,'2005-08-24','2012-03-25',2000,'Professor');
insert into occupy values(9,21,'1965-03-21','1979-04-16',1500,'Assistant Professor');
insert into occupy values(10,22,'1980-04-20','2010-01-16',3000,'Professor');
insert into occupy values(11,23,'1995-06-15','2005-05-18',1800,'Professor');
insert into occupy values(12,24,'1990-11-16','2007-07-20',1700,'Assistant Professor');
insert into occupy values(1,25,'1992-12-18','2000-08-22',3500,'Professor');
insert into occupy values(2,26,'2000-10-19','2020-11-23',4000,'Professor');
insert into occupy values(3,13,'2001-03-22','2009-12-25',500,'Lecturer');
insert into occupy values(4,28,'2003-02-23','2009-05-07',3600,'Professor');
insert into occupy values(5,29,'2000-05-30','2004-02-11',3000,'Assistant Professor');
insert into occupy values(6,30,'2005-08-24','2012-03-25',4000,'Professor');
insert into occupy values(7,31,'1965-03-21','1979-04-16',1200,'Assistant Professor');
insert into occupy values(8,32,'1980-04-20','2010-01-16',3000,'Professor');
insert into occupy values(9,33,'1995-06-15','2005-05-18',3000,'Professor');
insert into occupy values(10,34,'1990-11-16','2007-07-20',1700,'Assistant Professor');
insert into occupy values(11,35,'1992-12-18','2000-08-22',3500,'Professor');
insert into occupy values(12,2,'2000-10-19','2020-11-23',4000,'Professor');
insert into occupy values(1,3,'2001-03-22','2009-12-25',1100,'Lecturer');
insert into occupy values(2,4,'2003-02-23','2009-05-07',3600,'Professor');



--Sponsor
insert into sponsor values(1,'Intracom');
insert into sponsor values(2,'Nokia');
insert into sponsor values(3,'AT&T');
insert into sponsor values(4, 'Intel');
insert into sponsor values(5, 'NVIDIA');
insert into sponsor values(6, 'AMD');
insert into sponsor values(7, 'Apple');
insert into sponsor values(8, 'Micro$oft');

--Project
insert into project values(1,'Research Into Mobile Phone Connectivity');
insert into project values(2,'Research In Database Query Optimization');
insert into project values(3,'B+ Trees','1992-06-17');
insert into project values(4,'Research On Black Holes');
insert into project values(5, 'GPU Profiling using Python');
insert into project values(6, 'How to make people stupider in order to buy Windows','1985-04-25');
insert into project values(7, 'Running Prolog in optimized CPU', '2010-09-29');
insert into project values(8, 'Metric TSP optimizations','2010-02-15');

--Funds
insert into funds values(1,1,'1980-01-01',43432,'1995-01-01');
insert into funds values(1,1,'2000-01-01',900000);
insert into funds values(5,7,'1999-01-01',121321);
insert into funds values(6,6,'2003-01-01',439439);
insert into funds values(7,3,'2007-01-01',109293);

--Publication
insert into publication values (123,'All Pairs Shortest Paths Algorithms','Scientific America','1950-01-01',152);
insert into publication values (22,'Why NP Cannot Be Equal to P','IEEE Magazine','2002-03-20',140);
insert into publication values (442,'Erlang : The New Hope','IEEE Magazine','1942-04-20',42);
insert into publication values (6578,'DBMS and Olympiakos','IEEEMagazine','2002-06-20',284);
insert into publication values (1342,'Music effect on String Theory','Metal Hammer','1995-03-12',31);
insert into publication values (1,'Liquid Types in Python','Extreme Programming',  '2010-06-23', 37);
insert into publication values (49, 'Python API for AVR-ATmega16', 'AVR Freaks magazine','2004-08-08',0);
insert into publication values (2, 'Tralala laa', 'Omg magazine','2004-08-09',1);
insert into publication values (3, 'Convex optimization', 'ICCC','2002-08-09',1);
insert into publication values (4, 'In vitro cellular', 'Cancer Research','2001-08-09',3);
insert into publication values (5, 'Linear Programming stochastically', 'Journal on LP','1999-08-09',19);
insert into publication values (6, 'Dynamic Programming', 'ACM transactions','2004-08-09',100);
insert into publication values (7, 'Non-linear optimization', 'ACCM','2004-08-09',20);
insert into publication values (8, 'Traversal Graphs', 'AACAAC','2004-08-10',22);
insert into publication values (9, 'Microelectronic', 'IEEE 234/5','1999-08-09',6);
insert into publication values (10, 'In vivo', 'Cell research','2001-02-09',2);
insert into publication values (11, 'Non-Convex optimization', 'IEEE Transactions','2002-08-09',10);
insert into publication values (12, 'In vitro cellular', 'Cancer Research','2001-08-09',3);
insert into publication values (13, 'Integer Programming ', 'Pubmed','1939-08-09',19);
insert into publication values (14, 'Neural Programming', 'Ai-Transactions','1998-08-09',102);
insert into publication values (15, 'Discrete event systems', 'Sereies of lectures in DES','1922-08-09',20);
insert into publication values (16, 'Markovian Analysis', 'Spectrum','2001-08-10',22);
insert into publication values (17, 'DFS or BFS a comprehensive analysis', 'ACM Transactions in Computing','1999-08-09',11);
insert into publication values (18, 'Computing and Money', 'AACAAC','2004-08-10',22);
insert into publication values (19, 'Game theory', 'IEEE 234/5','1999-08-09',6);
insert into publication values (20, 'Quake 3 simulation', 'Cell research','2001-02-09',2);
insert into publication values (21, 'Selfish routin game', 'IEEE Transactions','2002-08-09',10);
insert into publication values (23, 'FTP transimision', 'Netwroks and Communications','2000-02-09',5);
insert into publication values (24, 'Robust control', 'IEEE Transactions','2002-08-09',10);
insert into publication values (25, 'Deiscrete mathematics', 'Cancer Research','2001-08-09',3);
insert into publication values (26, 'Pseudo Inverse ', 'Pubmed','1939-08-09',19);
insert into publication values (27, 'Svd Decomposition', 'Ai-Transactions','1998-08-09',102);
insert into publication values (28, 'Discrete event systems', 'Sereies of lectures in DES','1922-08-09',20);
insert into publication values (29, 'Markovian Analysis', 'Spectrum','2001-08-10',22);
insert into publication values (30, 'DFS or BFS a comprehensive analysis', 'ACM Transactions in Computing','1999-08-09',11);



--Suggests
insert into suggests values (2, 8, default, 'My kids are starving.', 100000,
    'Pending');
insert into suggests values (1, 3, default, 'DBMS for the poor.', 230000,
    'Approved');
insert into suggests values (1, 2, default, 'Erlang dializer in fighting the
    Greenhouse Effect', 80000, 'Approved');
insert into suggests values (3, 4, default, 'Advertising Soccerfun project.',
    44000, 'Approved');
insert into suggests values (3, 7, default, 'Approximation Algorithms for
    Flox-Networks.', 3000, 'Rejected');
insert into suggests values (1, 5, default, 'Request to become Olympiakos Head
    Coach.', 440000, 'Pending');
insert into suggests values (1, 1, default, 'Game Theory in TSP.', 65000,
    'Approved');

--Works_in
insert into works_in values (1, 1, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (1, 1, '2006-02-08', 7250, NULL);
insert into works_in values (1, 2, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (1, 2, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (2, 2, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (2, 2, '2006-02-08', 7250, NULL);
insert into works_in values (2, 3, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (2, 3, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (3, 3, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (3, 3, '2006-02-08', 7250, NULL);
insert into works_in values (3, 4, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (3, 4, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (4, 5, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (4, 5, '2006-02-08', 7250, NULL);
insert into works_in values (5, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (5, 6, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (6, 4, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (6, 4, '2006-02-08', 7250, NULL);
insert into works_in values (6, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (6, 6, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (7, 7, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (7, 7, '2006-02-08', 7250, NULL);
insert into works_in values (7, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (7, 8, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (7, 8, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (7, 2, '2006-02-08', 7250, NULL);
insert into works_in values (8, 1, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (8, 5, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (8, 2, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (9, 2, '2006-02-08', 7250, NULL);
insert into works_in values (9, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (9, 1, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (10, 8, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (10, 8, '2006-02-08', 7250, NULL);
insert into works_in values (10, 7, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (10, 7, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (10, 3, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (10, 5, '2006-02-08', 7250, NULL);
insert into works_in values (10, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (10, 3, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (11, 4, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (11, 4, '2006-02-08', 7250, NULL);
insert into works_in values (11, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (11, 6, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (11, 7, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (11, 7, '2006-02-08', 7250, NULL);
insert into works_in values (11, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (11, 8, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (11, 8, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (11, 3, '2006-02-08', 7250, NULL);
insert into works_in values (11, 1, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (11, 5, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (11, 2, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (11, 2, '2006-02-08', 7250, NULL);
insert into works_in values (10, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (11, 1, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (12, 1, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (12, 2, '2006-02-08', 7250, NULL);
insert into works_in values (12, 3, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (12, 3, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (12, 3, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (13, 4, '2006-02-08', 7250, NULL);
insert into works_in values (13, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (14, 7, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (14, 4, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (14, 4, '2006-02-08', 7250, NULL);
insert into works_in values (14, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (14, 6, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (15, 7, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (15, 7, '2006-02-08', 7250, NULL);
insert into works_in values (15, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (16, 8, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (16, 8, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (16, 3, '2006-02-08', 7250, NULL);
insert into works_in values (17, 1, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (17, 5, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (18, 2, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (19, 2, '2006-02-08', 7250, NULL);
insert into works_in values (20, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (21, 1, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (21, 1, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (21, 2, '2006-02-08', 7250, NULL);
insert into works_in values (22, 3, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (23, 3, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (24, 3, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (24, 4, '2006-02-08', 7250, NULL);
insert into works_in values (25, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (26, 7, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (16, 4, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (28, 4, '2006-02-08', 7250, NULL);
insert into works_in values (28, 6, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (28, 6, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (29, 7, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (30, 7, '2006-02-08', 7250, NULL);
insert into works_in values (30, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (30, 8, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (4, 8, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (4, 4, '2006-02-08', 7250, NULL);
insert into works_in values (5, 1, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (17, 8, '1904-07-24', 1000, '1964-08-27');
insert into works_in values (10, 2, '2008-04-18', 6000, '2010-01-15');
insert into works_in values (20, 2, '2006-02-08', 7250, NULL);
insert into works_in values (12, 8, '2002-10-10', 22000, '2005-01-09');
insert into works_in values (23, 1, '1904-07-24', 1000, '1964-08-27');

--Published
insert into published values (1, 123);
insert into published values (2, 442);
insert into published values (1, 442);
insert into published values (7, 22);
insert into published values (8, 22);
insert into published values (3, 6578);
insert into published values (2, 1);
insert into published values (2, 2);
insert into published values (3, 2);
insert into published values (3, 3);
insert into published values (4, 3);
insert into published values (4, 4);
insert into published values (5, 4);
insert into published values (6, 5);
insert into published values (6, 4);
insert into published values (6, 8);
insert into published values (6, 7);
insert into published values (6, 9);
insert into published values (7, 8);
insert into published values (7, 9);
insert into published values (7, 6);
insert into published values (7, 10);
insert into published values (8, 11);
insert into published values (8, 12);
insert into published values (8, 1);
insert into published values (9, 14);
insert into published values (9, 15);
insert into published values (9, 16);
insert into published values (10, 17);
insert into published values (11,18);
insert into published values (11, 19);
insert into published values (11, 20);
insert into published values (11, 21);
insert into published values (11, 22);
insert into published values (11,23);
insert into published values (11, 24);
insert into published values (11, 25);
insert into published values (11, 26);
insert into published values (11, 27);
insert into published values (11, 28);
insert into published values (12, 29);
insert into published values (12, 30);
insert into published values (13, 7);
insert into published values (13, 9);
insert into published values (14, 8);
insert into published values (14, 9);
insert into published values (15, 6);
insert into published values (16, 10);
insert into published values (17, 11);
insert into published values (18, 12);
insert into published values (19, 13);
insert into published values (20, 14);
insert into published values (21, 15);
insert into published values (22, 16);
insert into published values (23, 17);
insert into published values (22,18);
insert into published values (23, 19);
insert into published values (25, 20);
insert into published values (24, 21);
insert into published values (25, 22);
insert into published values (26,23);
insert into published values (25, 24);
insert into published values (28, 25);
insert into published values (29, 26);
insert into published values (30, 27);
insert into published values (31, 28);
insert into published values (32, 29);
insert into published values (33, 30);
