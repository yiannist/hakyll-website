#!/usr/bin/env python
#set et ts=4 sw=4
#
# This is the driver program of Pydbms - a Database Management System for the
# Academic World implemented in Python, Qt4, PostgreSQL.
#
# Authors: Yiannis Tsiouris (yiannis_t), Chris Stavrakakis (frenetic), 
#          Paris Siminelakis
#
##############################################################################
# This file is part of Pydbms software.
#
# Pydbms is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
##############################################################################

__author__='Paris Siminelakis, Chris Stavrakakis, Yiannis Tsiouris'
__version__='v0.1'

import sys
import re
import psycopg2 as pgsql
from PyQt4.QtCore import *
from PyQt4.QtGui import *

match = r'\((?P<%s>\w+),(?P<%s>\w+)\)'
mydb = None
mw = None
app = None

class WritableObject:
    """A simple class with a write method"""
    def __init__(self):
        self.content = []
    def write(self, string):
        self.content.append(string)

"""Forward stdout to file"""
#foo_dbg = WritableObject()
foo_dbg = open('debug_file','w')
sys.stdout = foo_dbg


def print_row(names, area, fmt=10, collapse=''):
    """Append Names list to QTextField with %fmt format"""
    if names:
        out = ''
        for i in range(0,len(names)):
            out = out + ('%' + str(fmt) + 's\t' + collapse) 
        area.appendPlainText(out % tuple(names))
        print out % tuple(names)


class InputError(Exception):
    """Exception class for Invalid Input"""
    def __init__(self, msg):
        self.msg = msg


class Warn(QMessageBox):
    """ Error Message Box """
    def __init__(self, msg='Uknown Error! Pray...', parent=None):
        QMessageBox.__init__(self, parent)
        self.setWindowTitle('Error!')
        self.setIcon(QMessageBox.Critical)
        self.setText(msg)


class DB:
    def __init__(self, *args, **kwargs):
        try:
            self.conn = pgsql.connect(*args, **kwargs)
            self.cur = self.conn.cursor()
        except pgsql.Error, e:
            warn = Warn('Error in connection! (%s)' % e.message, parent=mw)
            warn.show()
            print 'Error in connection:>> ', e.message
            sys.exit(1)

    def __del__(self):
        self.conn.close()

    def execute(self, args, query='select'):
        try:
            if query == 'select':
                self.cur.execute(args)
                return self.cur.fetchall(), None
            else:
                self.cur.execute(args)
                self.conn.commit()
        except pgsql.ProgrammingError, e:
            self.conn.rollback()
            print e.message
            raise InputError("""Information not Valid! Please reconsider your
                choices. (Tough guess: Did you enter a valid/existent
                code?)""")
            #warn = Warn('Error on executing command! (%s)' % e.message,
            #        parent=mw)
            #warn.show()
            return 'Error on executing command:>> ', e.message
        except pgsql.InternalError, e:
            self.conn.rollback()
            warn = Warn('Recovering from Error Transaction! (%s)' % e.message,
                    parent=mw)
            warn.show()
            return 'Recovering from Error Transaction:>> ', e.message

#
#----------------------WIDGETs Part--------------------------------------------
#
class InstitutionWidget(QWidget):
    """Institution Widget"""
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.parent = parent

        layout = QGridLayout()
        label0 = QLabel('Institutions:')
        ins_but = QPushButton('Browse')
        self.ins = QPlainTextEdit()
        self.ins.setReadOnly(1)
        label1 = QLabel('Select An Institution (by Code):')
        self.codearea = QLineEdit()
        label2 = QLabel('Schools of Selected Institution')
        sch_but = QPushButton('Find')
        self.schools = QPlainTextEdit()
        self.schools.setReadOnly(1)
        layout.addWidget(label0,0,0)
        layout.addWidget(self.ins,1,0,1,3)
        layout.addWidget(ins_but,2,2)
        layout.addWidget(label1, 3, 0)
        layout.addWidget(self.codearea, 3, 1)
        layout.addWidget(sch_but, 3, 2)
        layout.addWidget(label2,4,0,1,3)
        layout.addWidget(self.schools,5,0,1,3)
        
        self.connect(ins_but,SIGNAL('clicked()'),self.print_ins)
        self.connect(sch_but,SIGNAL('clicked()'),self.print_sch)
        self.setLayout(layout)

    def print_ins(self):
        rows,err = mydb.execute('SELECT inscode, name FROM institution')
        self.ins.clear()
        if not(err):
            todis = ['Institution Code',' Name']
            print_row(todis,self.ins,50)
            for row in rows:
                print_row(row,self.ins,50)

    def print_sch(self):
        school_code = self.codearea.text()
        try:
            if school_code=='':
                raise InputError('Please insert a valid Institution Code!')
            rows,err = mydb.execute('SELECT sch.name,sch.schcode from school as sch where sch.inscode =' +str(school_code))
            #if not(rows):
            #    raise InputError('Please insert a valid Institution Code!')
            self.schools.clear()
            todis = ['Name','School Code']
            print_row(todis, self.schools, 50)
            for row in rows:
                print_row(row, self.schools, 50)
        except InputError, err:
            print 'error'
            warn = Warn(err.msg, parent=mw)
            warn.show()



class SchoolWidget(QWidget):
    """School Widget"""
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.parent = parent

        layout = QGridLayout()
        
        label0 = QLabel('Schools:')
        self.sch_but = QPushButton('Browse')
        self.schools = QPlainTextEdit()
        self.schools.setReadOnly(True)
        label1 = QLabel('Find Useful Information for a School (by School Code)')
        self.sch_code = QLineEdit()
        self.head_but = QPushButton('Head')
        self.sum_but = QPushButton('Total Salaries')
        self.stat_but = QPushButton('Statistics')
        self.res = QPlainTextEdit()
        self.res.setReadOnly(True)
        layout.addWidget(label0,0,0)
        layout.addWidget(self.schools,1,0,1,3)
        layout.addWidget(self.sch_but,2,2)
        layout.addWidget(label1,3,0)
        layout.addWidget(self.sch_code,4,0,1,3)
        layout.addWidget(self.head_but,5,0)
        layout.addWidget(self.sum_but,5,1)
        layout.addWidget(self.stat_but,5,2)
        layout.addWidget(self.res,6,0,1,3)

        self.connect(self.sch_but,SIGNAL('clicked()'),self.print_sch)
        self.connect(self.head_but,SIGNAL('clicked()'),self.print_head)
        self.connect(self.sum_but,SIGNAL('clicked()'),self.print_sum)
        self.connect(self.stat_but,SIGNAL('clicked()'),self.print_stat)
        self.setLayout(layout)
    
    def print_sch(self):
        rows, err = mydb.execute("""select schcode,sch_name,ins_name from institution_schools""")
        self.schools.clear()
        if not(err):
            li = ['Id', 'Name', 'Institution']
            print_row(li, self.schools, 50)
            for row in rows:
                print_row(row, self.schools, 50)
 

    def print_head(self):
        try:
            school_code = self.sch_code.text()
            if school_code =='':
                raise InputError('Please insert a valid school code!')
            rows, err = mydb.execute("""select printname(e.name)
                as name from dep as d, school as s,
                researcher as e where ( (d.rescode = e.rescode) and (d.rescode=s.head)
                and (s.schcode = %s))""" % school_code)
            if not(rows):
                raise InputError('Please insert a valid school code!')
            self.res.clear()
            todis =[ 'Name Of President Of School']
            print_row(todis, self.res, 50)
            for row in rows:
                print_row(row,self.res, 50) 
        except InputError, err:
            print 'Error in print_head'
            warn = Warn(err.msg,parent=mw)
            warn.show()
    
    def print_sum(self):
        try:
            school_code = self.sch_code.text()
            if school_code =='':
                raise InputError('Please insert a valid school code!')
            rows,err = mydb.execute("""
            select sum(sallary) from school_occupys where schcode=%s and ended>current_date
                """ %school_code)
            #if not(rows[0][0]): #To fix strange return
            #    raise InputError('Please insert a valid school code!')
            self.res.clear()
            todis = ['Summary Of All Sallaries:']
            print_row(todis, self.res, 40)
            for row in rows:
                print_row(row, self.res,40)
        except InputError, err:
            print 'Error in print_sum'
            warn = Warn(err.msg,parent=mw)
            warn.show()
    

    def print_stat(self):
        try:
            school_code = self.sch_code.text()
            if school_code =='':
                raise InputError('Please insert a valid school code!')
            rows,err = mydb.execute("""select name,count(*),round(avg(sallary)) from school_occupys where schcode=%s group by schcode,name
                """ % school_code)
            if not(rows):
                raise InputError('Please insert a valid school code!')
            self.res.clear()
            lista = ['Name','Number Of Researchers','Average Researcher Sallary']
            print_row(lista,self.res,40)
            for row in rows:
                print_row(row,self.res,40)
        except InputError, err:
            print 'Error in print_stat'
            warn = Warn(err.msg, parent=mw)
            warn.show()
    

class ResearcherWidget(QWidget):
    """Researcher Widget"""
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.parent = parent
        layout = QGridLayout()

        label1 = QLabel('Researchers:')
        self.br_area = QPlainTextEdit()
        self.br_area.setReadOnly(1)
        self.br_but = QPushButton('Browse')
        self.dep_but = QPushButton('Dep')
        self.lab_but = QPushButton('Lab')
        label2 = QLabel('Give Researcher Code:')
        self.code_area = QLineEdit()
        self.deg_but = QPushButton('Degrees')
        self.sup_but = QPushButton('SuperVisor')
        self.wk_but = QPushButton('Worked')
        self.res_area = QPlainTextEdit()
        self.res_area.setReadOnly(1)
        self.res_area.setLineWrapMode(self.res_area.NoWrap)
        label5 = QLabel('Sort Researchers by Projects And Publications')
        self.sort_but = QPushButton('Sort')
        self.sort_area = QPlainTextEdit()
        self.sort_area.setReadOnly(1)
        self.sort_area.setLineWrapMode(self.res_area.NoWrap)

        layout.addWidget(label1, 0, 0)
        layout.addWidget(self.br_area,1,0,1,3)
        layout.addWidget(self.br_but,2,0)
        layout.addWidget(self.dep_but,2,1)
        layout.addWidget(self.lab_but,2,2)
        layout.addWidget(label2,3,0,1,2)
        layout.addWidget(self.code_area,3,2)
        layout.addWidget(self.deg_but,4,0)
        layout.addWidget(self.sup_but,4,1)
        layout.addWidget(self.wk_but,4,2)
        layout.addWidget(self.res_area,5,0,1,3)
        layout.addWidget(label5,6,0,1,2)
        layout.addWidget(self.sort_but,6,2)
        layout.addWidget(self.sort_area,7,0,1,3)

        self.connect(self.br_but,SIGNAL('clicked()'),self.print_brow)
        self.connect(self.dep_but,SIGNAL('clicked()'),self.print_dep)
        self.connect(self.lab_but,SIGNAL('clicked()'),self.print_lab)
        self.connect(self.deg_but,SIGNAL('clicked()'),self.print_deg)
        self.connect(self.sup_but,SIGNAL('clicked()'),self.print_sup)
        self.connect(self.wk_but,SIGNAL('clicked()'),self.print_wk)
        self.connect(self.sort_but,SIGNAL('clicked()'),self.print_sort)

        self.setLayout(layout)

    def print_brow(self):
        rows,err = mydb.execute("""select rescode, printname(name), site, email from researcher""")
        self.br_area.clear()
        if not(err):
            lista = ['Researcher Code','Name','Site','Email']
            print_row(lista, self.br_area,50)
            for row in rows:
                print_row(row, self.br_area, 50)
    
    def print_dep(self):
        rows,err = mydb.execute("""select r.rescode, printname(r.name), d.rank from
                researcher as r, dep as d where r.rescode = d.rescode""")
        self.br_area.clear()
        if not(err):
            lista = ['Researcher Code','Name','Rank']
            print_row(lista, self.br_area,50)
            for row in rows:
                print_row(row, self.br_area, 50)
    
    def print_lab(self):
        rows,err = mydb.execute("""select r.rescode,printname(r.name) from researcher as r, lab_researcher as l where r.rescode = l.rescode""")
        self.br_area.clear()
        if not(err):
            lista = ['Researcher Code','Name']
            print_row(lista, self.br_area,50)
            for row in rows:
                print_row(row, self.br_area, 50)
    
    def print_deg(self):
        try:
            res_code = self.code_area.text()
            if res_code=='':
                raise InputError('Please insert a valid Researcher Code!')
            rows,err = mydb.execute("""select printname(r.name), d.title,
                d.grade,d.year,s.name from researcher as r,degree as d ,school
                as s where r.rescode = %s and r.rescode=d.rescode and
                s.schcode=d.schcode""" % res_code)
            #if not(rows):
            #    raise InputError('Please insert a valid Researcher Code!')
            self.res_area.clear()
            lista = ['Name','Title','Grade','Year','School']
            print_row(lista, self.res_area,50)
            for row in rows:
                print_row(row, self.res_area, 50)
        except InputError, err:
            print 'Error in print_deg'
            warn = Warn(err.msg, parent=mw)
            warn.show()
    
    def print_sup(self):
        try:
            res_code = self.code_area.text()
            if res_code=='':
                raise InputError('Please insert a valid Researcher Code!')
            #---Error in query!----
            rows,err = mydb.execute(""" select r.rescode,printname(r.name), d.title, d.grade,
                d.year , s.name from researcher as r, degree as d, school as s
                where  d.profcode=%s and d.rescode=r.rescode and d.schcode =
                s.schcode""" % res_code)
            self.res_area.clear()
            lista = ['Researcher Code','Name','Title','Grade','Year','School']
            print_row(lista, self.res_area,50)
            for row in rows:
                print_row(row, self.res_area, 50)
        except InputError, err:
            print 'Error in print_sup'
            warn = Warn(err.msg, parent=mw)
            warn.show()
    

    def print_wk(self):
        try:    
            res_code = self.code_area.text()
            if res_code=='':
                raise InputError('Please insert a valid Researcher Code!')
            rows,err = mydb.execute("""
                select a.ins_name,b.name,b.rank,b.sallary,b.started,b.ended 
                from institution_schools as a 
                join (select * from school_occupys where rescode = %s) as b 
                on  a.schcode=b.schcode
                """ % res_code)
            #if not(rows):
            #    raise InputError('Please insert a valid Researcher Code!')
            self.res_area.clear()
            lista = ['Institution','School','Type','Started','Ended','Sallary']
            print_row(lista, self.res_area,50)
            for row in rows:
                print_row(row, self.res_area, 50)
        except InputError, err:
            print 'Error in print_wk'
            warn = Warn(err.msg, parent=mw)
            warn.show()
    

    def print_sort(self):
        rows,err = mydb.execute(""" select r.rescode,printname(r.name), pjb.proj_num,
                pjb.pub_num from researcher as r , (select pj.rescode
                ,pj.proj_num,pb.pub_num from (select rescode,count(*) as
                    proj_num from works_in group by rescode) as pj join (select
                        rescode,count(*) as pub_num from published group by
                        rescode) as pb on pj.rescode=pb.rescode) as pjb where
                    pjb.rescode = r.rescode order by pjb.proj_num
                    desc,pjb.pub_num desc""")
        self.sort_area.clear()
        if not(err):
            lista = ['Code','Name','Projects','Numbers']
            print_row(lista, self.sort_area,50)
            for row in rows:
                print_row(row, self.sort_area, 50)


class SponsorWidget(QWidget):
    """Sponsor Widget"""
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.parent = parent
        
        layout = QGridLayout()
        label1 =  QLabel('Sponsors:')
        self.spons = QPlainTextEdit()
        self.spons.setReadOnly(1)
        self.br_but = QPushButton('Browse')
        label2 = QLabel('Sort sponsors by:')
        self.sb_amount = QPushButton('Amount')
        self.sb_number = QPushButton('Number')
        label3 = QLabel('Pick a sponsor code and find the project that he funds')
        self.sp_code = QLineEdit()
        label4 = QLabel('Projects:')
        self.proj_but = QPushButton('Find')
        self.proj = QPlainTextEdit()
        self.proj.setReadOnly(1)

        layout.addWidget(label1,0,0,1,3)
        layout.addWidget(self.spons,1,0,1,3)
        layout.addWidget(self.br_but,2,0,1,1)
        layout.addWidget(label2,2,1,1,2)
        layout.addWidget(self.sb_amount,3,1,1,1)
        layout.addWidget(self.sb_number,3,2,1,1)
        layout.addWidget(label3,4,0,1,3)
        layout.addWidget(self.sp_code,5,0,1,1)
        layout.addWidget(self.proj_but,5,1,1,2)
        layout.addWidget(label4,6,0,1,3)
        layout.addWidget(self.proj,7,0,1,3)

        self.connect(self.br_but, SIGNAL('clicked()'), self.print_sponsors)
        self.connect(self.sb_amount, SIGNAL('clicked()'), self.sort_by_amount_sponsors)
        self.connect(self.sb_number, SIGNAL('clicked()'), self.sort_by_number_sponsors)
        self.connect(self.proj_but, SIGNAL('clicked()'), self.print_projects)
        
        self.setLayout(layout)
    
    def print_sponsors(self):
        rows,err = mydb.execute("""select sponcode, name, sptype from sponsor""")
        self.spons.clear()
        if not(err):
            lista = ['Sponsor Code','Name','Type']
            print_row(lista, self.spons,50)
            for row in rows:
                print_row(row, self.spons, 50)

    def sort_by_amount_sponsors(self):
        rows, err = mydb.execute("""select sponcode,name,round(avg(amount)) as am
            from sponsor_funds_project group by sponcode,name order by am desc """)
        self.spons.clear()
        if not(err):
            lista = ['Sponsor Code','Name','Amount']
            print_row(lista, self.spons,50)
            for row in rows:
                print_row(row, self.spons, 50)
    
    def sort_by_number_sponsors(self):
        rows, err = mydb.execute("""select sponcode,name,count(*) as number  from sponsor_funds_project group by sponcode,name order by number desc;
                """)
        self.spons.clear()
        if not(err):
            lista = ['Sponsor Code','Name','Number']
            print_row(lista, self.spons, 50)
            for row in rows:
                print_row(row, self.spons, 50)
 
    def print_projects(self):
        try:   
            spon_code = self.sp_code.text()
            if spon_code=='':
                raise InputError('Please insert a valid Sponsor Code!')
            rows, err = mydb.execute("""select distinct(title) from sponsor_funds_project where sponcode=%s
                """ % spon_code)
            #if not(rows):
            #    raise InputError('Please insert a valid Sponsor Code!')
            self.proj.clear()
            lista = ['Projects']
            print_row(lista, self.proj,50)
            for row in rows:
                print_row(row, self.proj, 50)
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()
 
 
class ProjectWidget(QWidget):
    """Projects Widget"""
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.parent = parent
        
        self.layout = QGridLayout()
        
        label1 = QLabel ('Projects:')
        self.proj_area = QPlainTextEdit()
        self.proj_area.setReadOnly(1)
        self.proj_but = QPushButton('Browse')
        label2 = QLabel('Pick a number of researchers')
        self.number_area = QLineEdit()
        self.num_but = QPushButton('Find')
        number = self.number_area.text()
        #self.label3 = QLabel('Projects with more than %s researchers' % number)
        self.proj2_area = QPlainTextEdit()
        self.proj2_area.setReadOnly(1)
        label4 = QLabel('Project Code:')
        self.proj_code = QLineEdit()
        self.res_but = QPushButton('Find')
        self.res_area = QPlainTextEdit()
        self.res_area.setReadOnly(1)
        label5 = QLabel('Find the Institutions that take part in Project:')
        self.ins_code = QLineEdit()
        self.ins_but = QPushButton('Find')
        self.ins_res = QPlainTextEdit()
        self.ins_res.setReadOnly(1)

        self.layout.addWidget(label1,0,0,1,3)
        self.layout.addWidget(self.proj_area,1,0,1,3)
        self.layout.addWidget(self.proj_but,2,2,1,1)
        self.layout.addWidget(label2,4,0,1,1)
        self.layout.addWidget(self.number_area,4,1,1,1)
        self.layout.addWidget(self.num_but,4,2,1,1)
        self.layout.addWidget(self.proj2_area,6,0,1,3)
        self.layout.addWidget(label4,7,0,1,1)
        self.layout.addWidget(self.proj_code,7,1,1,1)
        self.layout.addWidget(self.res_but,7,2,1,1)
        self.layout.addWidget(self.res_area,8,0,1,3)
        self.layout.addWidget(label5,9,0)
        self.layout.addWidget(self.ins_code,9,1)
        self.layout.addWidget(self.ins_but,9,2)
        self.layout.addWidget(self.ins_res,10,0,1,3)
        self.newlabel = QLabel('')
        self.layout.addWidget(self.newlabel,5,0,1,3)

        self.connect(self.proj_but,SIGNAL('clicked()'),self.print_proj)
        self.connect(self.num_but,SIGNAL('clicked()'),self.print_proj2)
        self.connect(self.res_but,SIGNAL('clicked()'),self.print_res)
        self.connect(self.ins_but,SIGNAL('clicked()'),self.print_ins)


        self.setLayout(self.layout)

    def print_proj(self):
        rows, err = mydb.execute("""select projcode,title from project""")
        self.proj_area.clear()
        if not(err):
            lista = ['Project Code','Title']
            print_row(lista, self.proj_area,50)
            for row in rows:
                print_row(row, self.proj_area, 50)

    def print_proj2(self):
        try:
            number = self.number_area.text()
            if number=='':
                raise InputError('Please insert a number!')
            rows, err = mydb.execute("""select p.projcode, p.title, w.number from
                project as p , ( select projcode, count(*) as number from
                works_in group by projcode ) as w where w.projcode = p.projcode
                and number > %s
                order by number desc""" % number)
            self.proj2_area.clear()
            lista = ['Project Code','Name','Number']
            print_row(lista, self.proj2_area, 50)
            for row in rows:
                print_row(row, self.proj2_area, 50)
            self.newlabel.setText('Projects with more than %s researchers' %number)
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()
    
    def print_res(self):
        try:
            number = self.proj_code.text()
            if number=='':
                raise InputError('Please insert a valid Project Code!')
            rows, err = mydb.execute("""select rw.rescode,printname(rw.name) from
            (select r.rescode as rescode, r.name as name ,w.projcode as projcode
            from researcher as r,works_in as w where w.rescode=r.rescode) as rw
            where rw.projcode =  %s """ % number)
            if not(rows):
                raise InputError('Please insert a valid Project Code!')
            self.res_area.clear()
            lista = ['Researcher Code','Name']
            print_row(lista, self.res_area,50)
            for row in rows:
                print_row(row, self.res_area, 50)
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()
 
    def print_ins(self):
        try:
            ins_code = self.ins_code.text()
            if ins_code=='':
                raise InputError('Please insert a valid Project Code!')
            rows, err = mydb.execute("""
                select distinct(a.ins_name) from 
                (select ins.ins_name,occ.rescode from institution_schools as ins,school_occupys as occ where occ.schcode=ins.schcode) as a join
                (select rescode from works_in where projcode=%s) as b on a.rescode=b.rescode

                """ % ins_code)
            if not(rows):
                raise InputError('Please insert a valid Project Code!')
            self.ins_res.clear()
            lista = ['Institutions']
            print_row(lista, self.ins_res,50)
            for row in rows:
                print_row(row, self.ins_res, 50)
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()
 

class PublicationWidget(QWidget):
    """Publications Widget"""
    def __init__(self,parent=None):
        QWidget.__init__(self,parent)
        self.parent = parent
        
        layout = QGridLayout()
        label1 = QLabel('Publications:')
        self.pub_area = QPlainTextEdit()
        self.pub_area.setReadOnly(1)
        self.pub_but = QPushButton('Browse')
        label2 = QLabel('Find a Publication with References more than')
        self.num_area = QLineEdit()
        self.num_but = QPushButton('Find')
        self.num_res = QPlainTextEdit()
        self.num_res.setReadOnly(1)
        label3 = QLabel('Find the Research with Most Publications')
        self.most_but = QPushButton('Find')
        self.most_res = QPlainTextEdit()
        self.most_res.setReadOnly(1)

        layout.addWidget(label1, 0, 0, 1, 3)
        layout.addWidget(self.pub_area, 1, 0, 1, 3)
        layout.addWidget(self.pub_but, 2 , 2)
        layout.addWidget(label2, 3, 0)
        layout.addWidget(self.num_area, 3, 1)
        layout.addWidget(self.num_but, 3, 2)
        layout.addWidget(self.num_res, 4, 0, 1, 3)
        layout.addWidget(label3, 5, 0)
        layout.addWidget(self.most_but, 5, 2)
        layout.addWidget(self.most_res, 6, 0, 1, 3)
        
        self.setLayout(layout)
        self.connect(self.pub_but,SIGNAL('clicked()'),self.print_pub)
        self.connect(self.num_but,SIGNAL('clicked()'),self.print_num)
        self.connect(self.most_but,SIGNAL('clicked()'),self.print_res) 
    
    def print_pub(self):
        rows, err = mydb.execute("""select pubcode,title from publication """)
        self.pub_area.clear()
        if not(err):
            lista = ['Publication Code','Title']
            print_row(lista, self.pub_area,50)
            for row in rows:
                print_row(row, self.pub_area, 50)

    def print_num(self):
        try:
            number = self.num_area.text()
            if number=='':
                raise InputError('Please insert a number!')
            rows, err = mydb.execute("""select pubcode,title,refers from publication where (refers > %s)""" % number)
            self.num_res.clear()
            lista = ['Publication Code','Title','Refers']
            print_row(lista, self.num_res, 50)
            for row in rows:
               print_row(row, self.num_res, 50)
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()

    def print_res(self):
       rows, err = mydb.execute(""" select res.rescode, printname(res.name), pp.count from 
                                    (select rescode,count(*) from published group by rescode) as pp,
                                    researcher as res 
                                    where pp.rescode=res.rescode 
                                    order by count desc""")
       self.most_res.clear()
       if not(err):
         lista = ['Researcher Code','Name','Publications']
         print_row(lista, self.most_res, 50)
         print_row(rows[0], self.most_res, 50)


class StartWidget(QWidget):
    """Central Introduction Widget"""
    def __init__(self, parent=None): 
        QWidget.__init__(self, parent)
        self.parent = parent
        
        layout = QGridLayout()
        self.ins_but = QPushButton('Institution')
        self.sch_but = QPushButton('School')
        self.res_but = QPushButton('Researcher')
        self.spo_but = QPushButton('Sponsor')
        self.pro_but = QPushButton('Project')
        self.pub_but = QPushButton('Publication')
        self.superbut = QPushButton('Modify DB!')
        layout.addWidget(self.ins_but, 0, 0)
        layout.addWidget(self.sch_but, 0, 1)
        layout.addWidget(self.res_but, 0, 2)
        layout.addWidget(self.spo_but, 1, 0)
        layout.addWidget(self.pro_but, 1, 1)
        layout.addWidget(self.pub_but, 1, 2)
        layout.addWidget(self.superbut, 2, 1)
        self.setLayout(layout)
        self.connect(self.ins_but, SIGNAL('clicked()'),self.initIns)
        self.connect(self.sch_but, SIGNAL('clicked()'),self.initSch)
        self.connect(self.res_but, SIGNAL('clicked()'), self.initRes)
        self.connect(self.spo_but, SIGNAL('clicked()'), self.initSpo)
        self.connect(self.pro_but, SIGNAL('clicked()'), self.initPro)
        self.connect(self.pub_but, SIGNAL('clicked()'), self.initPub)
        self.connect(self.superbut, SIGNAL('clicked()'), self.createWizard)

        self.ins_but.setToolTip('Browse Institutions')
        self.sch_but.setToolTip('Browse Schools')
        self.res_but.setToolTip('Browse Researchers')
        self.spo_but.setToolTip('Browse Sponsors')
        self.pro_but.setToolTip('Browse Projects')
        self.pub_but.setToolTip('Browse Publications')
        self.superbut.setToolTip('Extraordinary Button')
    
    def initIns(self):
        self.emit(SIGNAL('cwChange'),'InstitutionWidget()', 'Institutions')
        self.close()

    def initSch(self):
        self.emit(SIGNAL('cwChange'),'SchoolWidget()', 'Schools')
        self.close()

    def initRes(self):
        self.emit(SIGNAL('cwChange'), 'ResearcherWidget()','Researchers')
        self.close()

    def initSpo(self):
        self.emit(SIGNAL('cwChange'),'SponsorWidget()', 'Sponsors')
        self.close()

    def initPro(self):
        self.emit(SIGNAL('cwChange'),'ProjectWidget()','Projects')
        self.close()
    
    def initPub(self):
        self.emit(SIGNAL('cwChange'),'PublicationWidget()','Publications')
        self.close()

    def createWizard(self):
        self.mwiz = MyWizard()
        self.mwiz.show()


class MainWindow(QMainWindow):
    """Main Window for all Widgets"""
    global app
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)

        self.setWindowTitle('Academic World Application')
        self.resize(1001,800)
        self.center()
        self.home = QAction(QIcon('icons/home.gif'),'Home',self)
        self.home.setShortcut('Ctrl+H')

        self.home.setStatusTip('Return To Home Page')
        self.connect(self.home, SIGNAL('triggered()'), self.set_home)
        self.exit = QAction(QIcon('icons/exit.jpg'),'Exit',self)
        self.exit.setShortcut('Ctrl+Q')
        self.exit.setStatusTip('Exit Application')
        self.connect(self.exit,SIGNAL('triggered()'),self,SLOT('close()'))

        self.aboutUs = QAction(QIcon('icons/about.png'),'&About',self)
        self.connect(self.aboutUs, SIGNAL('triggered()'), self.about)
        self.aboutQtAct = QAction('About &Qt', self)
        self.connect(self.aboutQtAct, SIGNAL("triggered()"), app, SLOT("aboutQt()"))
      
        self.fullscreen = QAction('Full Screen',self)
        self.fullscreen.setShortcut('Alt+F11')
        self.connect(self.fullscreen,SIGNAL('triggered()'),self.setfull)
        self.normal = QAction('Normal Size',self)
        self.connect(self.normal,SIGNAL('triggered()'),self.setnormal)
        menubar = self.menuBar()
        file = menubar.addMenu('&File')
        view = menubar.addMenu('&View') 
        about = menubar.addMenu('&Help')

        file.addAction(self.home)
        file.addAction(self.exit)
        view.addAction(self.fullscreen)
        view.addAction(self.normal)
        about.addAction(self.aboutUs)
        about.addAction(self.aboutQtAct)

        self.statusBar()
        self.setStatusTip('Ready')
        font = QFont('Linux Libertine 0',10,QFont.Normal)
        font.setCapitalization(QFont.SmallCaps)
        self.setFont(font)
        self.toolbar = self.addToolBar('Home')
        self.toolbar.addAction(self.home)
        self.toolbar.addAction(self.exit)

        self.setToolTip('This is an <i> Academic World </i> Application')
        self.cw = StartWidget()
        self.setCentralWidget(self.cw)

        self.connect(self.cw, SIGNAL('cwChange'), self.set_central)

    def setfull(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def setnormal(self):
        self.showNormal()

    def set_central(self, widget, title):
        self.cw = eval(widget)
        self.setWindowTitle(title)
        self.setCentralWidget(self.cw)
        self.cw.show()

    def set_home(self):
        self.cw.close()
        self.cw = StartWidget();
        self.setWindowTitle('Academic World Application')
        self.setCentralWidget(self.cw)
        self.connect(self.cw, SIGNAL('cwChange'), self.set_central)

    def about(self):
        QMessageBox.about(self, 'We are who we are!', '%s\n %s\n' %
                (__author__, __version__))
       
    def center(self):
        screen = QDesktopWidget().screenGeometry()
        size =  self.geometry()
        self.move((screen.width()-size.width())/2,
                 (screen.height()-size.height())/2)


class ResForm(QWidget):
    """
    Form Widget for DB operations
    """
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        layout = QFormLayout()
        self.nle = QLineEdit()
        self.nlbl = QLabel('Name:')
        layout.addRow(self.nlbl, self.nle)
        self.ple = QLineEdit()
        self.plbl = QLabel('Phone:')
        layout.addRow(self.plbl, self.ple)
        self.sle = QLineEdit()
        self.slbl = QLabel('Site:')
        layout.addRow(self.slbl, self.sle)
        self.ele = QLineEdit()
        self.elbl = QLabel('Email:')
        layout.addRow(self.elbl, self.ele)
        self.loc = QWidget()
        loclayout = QHBoxLayout()
        self.loc.setLayout(loclayout)
        self.cle = QLineEdit()
        self.clbl = QLabel('Country:')
        self.cile = QLineEdit()
        self.cilbl = QLabel('City:')
        loclayout.addWidget(self.clbl)
        loclayout.addWidget(self.cle)
        loclayout.addWidget(self.cilbl)
        loclayout.addWidget(self.cile)
        layout.addRow(self.loc)
        #self.ale = QLineEdit()
        #self.albl = QLabel('Address:')
        #layout.addRow(self.albl, self.ale)
         
        self.setLayout(layout)

    def clearAll(self):
        self.nle.clear()
        self.ple.clear()
        self.sle.clear()
        self.ele.clear()
        self.cle.clear()
        self.cile.clear()


class SchForm(QWidget):
    """
    Form Widget for DB operations
    """
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        layout = QFormLayout()
        self.nle = QLineEdit()
        self.nlbl = QLabel('Name:')
        layout.addRow(self.nlbl, self.nle)
        self.hle = QLineEdit()
        self.hlbl = QLabel('Head:')
        layout.addRow(self.hlbl, self.hle)
        self.yle = QLineEdit()
        self.ylbl = QLabel('Year Founded:')
        layout.addRow(self.ylbl, self.yle)
        self.setLayout(layout)

    def clearAll(self):
        self.nle.clear()
        self.hle.clear()
        self.yle.clear()

#
#--------------------Modify WIZARD Part------------------------------------
#
class MyWizard(QWizard):
    """Generic Wizard Class"""
    def __init__(self, parent=None):
        QWizard.__init__(self, parent)
        self.setWindowTitle('Modify Database Wizard')
        self.resize(1200,700)
        self.setWizardStyle(QWizard.MacStyle)
        self.pages = {'IntroPage':1, 'ResPage':2, 'InsPage':3, 'FinPage':4}
        self.setPage(self.pages['IntroPage'], IntroWizPage(self))
        self.setPage(self.pages['ResPage'], ResWizPage(self))
        self.setPage(self.pages['InsPage'], InsWizPage(self))
        self.setPage(self.pages['FinPage'], FinWizPage(self))


class IntroWizPage(QWizardPage):
    """Introduction Page for Wizard"""
    def __init__(self, parent=None):
        QWizardPage.__init__(self, parent)
        self.parent = parent
        self.setTitle('Modify Database Wizard')
        self.setSubTitle("Quick'n'Dirty way to edit tables")
        self.label = QLabel('Select the table you wish to modify:')
        self.res_radio = QRadioButton('Researcher')
        self.res_radio.setChecked(True)
        self.ins_radio = QRadioButton('Institution')
        #self.sch_radio = QRadioButton('School')
        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.res_radio)
        layout.addWidget(self.ins_radio)
        #layout.addWidget(self.sch_radio)
        self.setLayout(layout)

    def nextId(self):
        """Reimplement QWizardPage::nextId because of Non-Linear Wizard"""
        if self.ins_radio.isChecked():
            return self.parent.pages['InsPage']
        else: #self.res_radio.isChecked():
            return self.parent.pages['ResPage']
        #elif self.sch_radio.isChecked():
            #return self.parent.pages['SchPage']


class FinWizPage(QWizardPage):
    """Final/Pozer Page"""
    def __init__(self, parent=None):
        QWizardPage.__init__(self, parent)
        self.parent = parent
        self.setTitle('Good Game!')
        self.setSubTitle('Cool Wizard, ha? ;-)')
        self.setPixmap(QWizard.BackgroundPixmap,QPixmap('icons/success.png'))
        layout = QVBoxLayout()
        self.setLayout(layout)

    def nextId(self):
        return -1


class InsWizPage(QWizardPage):
    """Modify Institution Wizard Page"""
    def __init__(self, parent=None):
        QWizardPage.__init__(self, parent)
        self.parent = parent
        print 'Insert Institution'
        layout = QGridLayout()
        layout1 = QHBoxLayout()
        layout2 = QHBoxLayout()

        label1 = QLabel('Schools:')
        self.br_area = QPlainTextEdit()
        self.br_area.setReadOnly(1)
        self.br_area.setLineWrapMode(self.br_area.NoWrap)
        self.br_but = QPushButton('Browse')
        self.clr_but = QPushButton('Clear')
        label2 = QLabel('Actions:')
        self.ins_but = QRadioButton('Insert')
        self.del_but = QRadioButton('Delete')
        self.mod_but = QRadioButton('Modify')
        self.del_code = QLineEdit()
        self.mod_code = QLineEdit()
        #label3 = QLabel('Search:')
        #self.ins_code = QLineEdit()
        self.find_but = QPushButton('Set Fields')

        label4 = QLabel('(Fields with * not null)')
        label5 = QLabel('*Name')
        label6 = QLabel('Year Founded')
        label7 = QLabel('Site')
        label8 = QLabel('*Country')
        label9 = QLabel('*City')
        self.do_but = QPushButton('Do It!')

        self.code_area = QLineEdit()
        self.name_area = QLineEdit()
        self.year_area = QLineEdit()
        self.site_area = QLineEdit()
        self.country_area = QLineEdit()
        self.city_area = QLineEdit()
        
        layout1.addWidget(self.del_but)
        layout2.addWidget(self.mod_but)
        layout1.addWidget(self.del_code)
        layout2.addWidget(self.mod_code)

        layout.addWidget(label1,0,0)
        layout.addWidget(self.br_area,1,0,1,4)
        layout.addWidget(self.br_but,2,0)
        layout.addWidget(label2,3,0)
        layout.addWidget(self.ins_but,3,1)
        layout.addLayout(layout1,3,2)
        layout.addLayout(layout2,3,3)
        #layout.addWidget(label3,4,0)
        #layout.addWidget(self.ins_code,4,1)
        layout.addWidget(self.find_but,4,3)
        layout.addWidget(label4,5,0)
        #layout.addWidget(self.code_area,5,1)
        layout.addWidget(label5,6,0)
        layout.addWidget(self.name_area,6,1,1,2)
        layout.addWidget(label6,7,0)
        layout.addWidget(self.year_area,7,1,1,2)
        layout.addWidget(label7,8,0)
        layout.addWidget(self.site_area,8,1,1,2)
        layout.addWidget(label8,9,0)
        layout.addWidget(self.country_area,9,1,1,2)
        layout.addWidget(label9,10,0)
        layout.addWidget(self.city_area,10,1,1,2)
        layout.addWidget(self.clr_but,11,0)
        layout.addWidget(self.do_but,11,3)


        self.connect(self.br_but,SIGNAL('clicked()'), self.print_ins)
        self.connect(self.clr_but,SIGNAL('clicked()'), self.clear_all)
        self.connect(self.find_but,SIGNAL('clicked()'), self.fill_blanks)
        self.connect(self.do_but,SIGNAL('clicked()'), self.get_radio)
        self.setLayout(layout)

    def nextId(self):
        return self.parent.pages['FinPage']

    def clear_all(self):
        self.br_area.clear()
        self.name_area.clear()
        self.year_area.clear()
        self.site_area.clear()
        self.country_area.clear()
        self.city_area.clear()

    def print_ins(self):
        rows, err = mydb.execute("""select ins.inscode,
        ins.name, ins.yfounded, ins.site, printlocation(ins.loc) from
                institution as ins""") 
        if not(err):
            lista = ['Code','Name','Year Founded','Site','Location']
            print_row(lista, self.br_area, 25)
            for row in rows:
                print_row(row, self.br_area, 25)
            self.br_area.appendPlainText(' ')
   
    def get_radio(self):
        if self.ins_but.isChecked():
            self.do_insert()
        elif self.del_but.isChecked():
            self.do_delete()
        elif self.mod_but.isChecked():
            self.do_alter()

    def fill_blanks(self):
        try:
            #self.clear_all()
            #ins_code = self.ins_code.text()
            ins_code = self.mod_code.text()
            if ins_code=='':
                raise InputError("""Please click Modify radiobutton and insert 
                a valid Institution Code!""")
            rows, err = mydb.execute("""select name, yfounded, site, loc from
            institution where inscode = %s """ % ins_code)
            try:
                row = rows[0]
            except IndexError:
                raise InputError("""Please insert an existent Institution Code!
                        (press Browse to see all Institutions available)""")
            self.name_area.setText(row[0])
            if (row[1]):
                self.year_area.setText(str(row[1]))
            else:
                self.year_area.clear()
            if (row[2]):
                self.site_area.setText(row[2])
            else:
                self.site_area.clear()
            p = re.compile(match % ('cou','cit'))
            m = p.match(row[3])
            self.country_area.setText(m.group('cou'))
            self.city_area.setText(m.group('cit'))
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()


    def do_insert(self):
        try:
            mods = []
            mods.append(r'default')
            if self.name_area.isModified():
                mods.append("'%s'" % self.name_area.text() )
            else:
                raise InputError('Name is an Important Field!')

            if self.year_area.isModified():
                if self.year_area.text()=='':
                    mods.append(r'NULL')
                else:
                    mods.append("%s" % self.year_area.text() )
            else:
                mods.append(r'NULL')
            if self.site_area.isModified():
                mods.append("'%s'" % self.site_area.text() )
            else:
                mods.append(r'NULL')
            
            if self.country_area.text()!='' and self.city_area.text()!='':
                mods.append("('%s','%s')" % (self.country_area.text(),
                                            self.city_area.text()))
            else:
                raise InputError('Location is vital for us.')
            print mods
            mods = '('+','.join(mods)+')'
            mydb.execute(
                    """ INSERT INTO institution VALUES %s""" % mods,'insert')
        except InputError, err:
            print 'eroor'
            warn = Warn(err.msg, parent=mw)
            warn.show()

    def do_delete(self):
        try:
            ins_code = self.del_code.text()
            if ins_code=='':
                raise InputError("""Please insert a valid Institution Code to
                        delete!""")
            mydb.execute( """DELETE FROM institution WHERE inscode = %s """ %
                    ins_code,'delete')
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()

    def do_alter(self):
        try:
            ins_code = self.mod_code.text()
            if ins_code == '':
                raise InputError("""Please insert a valid Institution Code to
                        modify!""")
            mods = []
            if self.name_area.isModified():
                mods.append("name = '%s'" % self.name_area.text())
            if self.year_area.isModified():
                mods.append("yfounded = %d" % int(self.year_area.text()))
            if self.site_area.isModified():
                mods.append("site = '%s'" % self.site_area.text())
            if self.country_area.text()!='' and self.city_area.text()!='':
                mods.append("loc = ('%s','%s')" % (self.country_area.text(),
                self.city_area.text()))
            print ','.join(mods)
            mydb.execute("""UPDATE institution SET %s WHERE inscode = %s""" %
                    (','.join(mods), ins_code),'update')
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()


class ResWizPage(QWizardPage):
    """Modify Researcher Wizard Page"""
    global mydb, mw, match
    def __init__(self, parent=None):
        QWizardPage.__init__(self, parent)
        self.parent = parent

        layout = QGridLayout()
        self.brl = QLabel('Browse:')
        self.res = QPlainTextEdit()
        self.res.setReadOnly(True)
        self.actl= QLabel('Actions:')
        self.mod = QRadioButton('Modify')
        self.dele = QRadioButton('Delete')
        self.inse = QRadioButton('Insert')
        self.midl = QLineEdit()
        self.didl = QLineEdit()
        self.srch_but = QPushButton('Set fields')
        self.brow_but = QPushButton('Browse')
        self.clear_but = QPushButton('Clear')
        self.do_but = QPushButton('Do!')
        layout.addWidget(self.brl, 1,0)
        layout.addWidget(self.res, 2,0, 3,4)
        layout.addWidget(self.brow_but, 5, 2)
        layout.addWidget(self.clear_but, 5, 3)
        layout.addWidget(self.actl, 6,0)
        layout.addWidget(self.mod, 6,1)
        layout.addWidget(self.midl, 6,2)
        layout.addWidget(self.srch_but, 7,2)
        layout.addWidget(self.dele, 8,1)
        layout.addWidget(self.didl, 8,2)
        layout.addWidget(self.inse, 9,1)
        self.modForm = ResForm()
        layout.addWidget(self.modForm, 6,3)
        layout.addWidget(self.do_but, 10,3)
        self.setLayout(layout)

        self.connect(self.brow_but, SIGNAL('clicked()'), self.browseAll)
        self.connect(self.clear_but, SIGNAL('clicked()'), self.clearAll)
        self.connect(self.mod, SIGNAL('clicked()'), self.getRadio)
        self.connect(self.dele, SIGNAL('clicked()'), self.getRadio)
        self.connect(self.inse, SIGNAL('clicked()'), self.getRadio)

    def nextId(self):
        return self.parent.pages['FinPage']

    def clearAll(self):
        self.res.clear()
        self.modForm.clearAll()

    def browseAll(self):
        rows, err = mydb.execute('SELECT rescode, printname(name), phone, site, email, printlocation(loc) FROM researcher')
        if not err:
            cols = ['Id', 'Name', 'Phone', 'Site', 'Email', 'Location']
            fmt = 25                                       
            print_row(cols, self.res, fmt)
            #line = len(cols)*(fmt+1)*['-']                 #Add Separator
            #print_row(line, self.res, collapse='') 
            for row in rows:
                print_row(row, self.res, fmt)
            self.res.appendPlainText(' ')

    def getRadio(self):
        self.disconnect(self.do_but, SIGNAL('released()'), self.do_delete)
        self.disconnect(self.do_but, SIGNAL('released()'), self.do_mod)
        self.disconnect(self.do_but, SIGNAL('released()'), self.do_insert)
        if self.mod.isChecked():
            print 'Modify Mode'
            self.connect(self.srch_but, SIGNAL('clicked()'), self.do_search)
            self.connect(self.do_but, SIGNAL('released()'), self.do_mod)
        elif self.dele.isChecked():
            print 'Delete Mode'
            self.connect(self.do_but, SIGNAL('released()'), self.do_delete)
        elif self.inse.isChecked():
            print 'Insert Mode'
            self.modForm.clearAll()
            self.connect(self.do_but, SIGNAL('released()'), self.do_insert)

    def do_search(self):
        try:
            self.val = int(self.midl.text())
            li, err = mydb.execute("""select * from %s where %s = %d""" %
                    ('researcher','rescode', self.val))

            li = li[0]
            #Regular Expressions ftw!
            p = re.compile(match % ('name', 'surname'))
            m = p.match(li[1])
            name = m.group('name')
            surname = m.group('surname')
            self.modForm.nle.setText(name + ' ' + surname)
            if li[2]:
                self.modForm.ple.setText(li[2])
            else:
                self.modForm.ple.clear()
            if li[3]:
                self.modForm.sle.setText(li[3])
            else:
                self.modForm.sle.clear()
            if li[4]:
                self.modForm.ele.setText(li[4])
            else:
                self.modForm.ele.clear()
            p = re.compile(match % ('cit','cou'))
            m = p.match(li[5])
            self.modForm.cle.setText(m.group('cit'))
            self.modForm.cile.setText(m.group('cou'))
        except IndexError, e: 
            #Id not found in db (<=> li=None)
            warn = Warn("""Invalid Id!\n Hint: Be sure about what you type,
                    dude!\n\n (%s)""" % e.message, parent=mw)
            warn.show()
        except ValueError, e:
            #No id typed in Modify LineEdit area
            warn = Warn('Please insert a valid Researcher Code!', parent=mw)
            warn.show()

    def do_mod(self):
        #Do the modification on Do! click
        try:
            if self.val==0:
                raise InputError('Please insert a valid Researcher Code!')
            mods = []
            if self.modForm.nle.isModified(): #isModified Fix
                inp = self.modForm.nle.text().split(' ')
                mods.append("name=('%s','%s')" % (inp[0],inp[1]))
            if self.modForm.ple.isModified():
                mods.append("phone='%s'" % self.modForm.ple.text())
            if self.modForm.sle.isModified():
                mods.append("site='%s'" % self.modForm.sle.text())
            if self.modForm.ele.isModified():
                mods.append("email='%s'" % self.modForm.ele.text())
            if self.modForm.cle.isModified():
                mods.append("loc=('%s','%s')" % (self.modForm.cle.text(),
                self.modForm.cile.text()))
            if self.modForm.cile.isModified():
                mods.append("loc=('%s','%s')" % (self.modForm.cle.text(),
                    self.modForm.cile.text()))
            print """UPDATE %s SET %s WHERE %s = %d""" % ('researcher',
                        ','.join(mods), 'rescode', self.val)
            mydb.execute("""UPDATE %s SET %s WHERE %s = %d""" % ('researcher',
                    ','.join(mods), 'rescode', self.val), 'update')
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()
        except AttributeError:
            warn = Warn("""Please insert a valid Reserarcher Code!""",
                    parent=mw)
            warn.show()

    def do_delete(self):
        try:
            print  """DELETE FROM %s WHERE %s = %d""" % ('researcher', 'rescode',
                    int(self.didl.text()))
            mydb.execute("""DELETE FROM %s WHERE %s = %d""" % ('researcher', 'rescode',
                int(self.didl.text())),'delete')
        except ValueError, e:
            #No Id inserted
            warn = Warn('Please insert a valid Researcher Code to delete!', parent=mw)
            warn.show()

    def do_insert(self):
        try:
            mods = []
            mods.append(r'default')
            if self.modForm.nle.isModified():
                inp = self.modForm.nle.text().split(" ")
                try:
                    mods.append("('%s','%s')" % (inp[0],inp[1]))
                except IndexError,err:
                    raise InputError('Name should be of the form: <Name Surname>')
            else:
                raise InputError('Name is an Important Field!')
            if self.modForm.ple.isModified():
                mods.append("'%s'" % self.modForm.ple.text())
            else:
                mods.append(r'NULL')
            if self.modForm.sle.isModified():
                mods.append("'%s'" % self.modForm.sle.text())
            else:            
                mods.append(r'NULL')
            if self.modForm.ele.isModified():
                mods.append("'%s'" % self.modForm.ele.text())
            else:
                mods.append(r'NULL')
            if self.modForm.cle.text()!='' and self.modForm.cile.text()!='':
                mods.append("('%s','%s')" % (self.modForm.cle.text(),
                    self.modForm.cile.text()))
            else:
                raise InputError('Location is vital for us.')
            mods.append(r'NULL')
            print mods
            mods = '(' + ','.join(mods) + ')'
            print """INSERT INTO %s VALUES %s""" % ('researcher',mods)
            mydb.execute("""INSERT INTO %s VALUES %s""" % ('researcher', mods), 'insert')
        except InputError, err:
            warn = Warn(err.msg, parent=mw)
            warn.show()


def main():
    global mydb, mw, app, foo_dbg
    if len(sys.argv) == 2 and sys.argv[1] == 'acad_world':
        mydb = DB(database=sys.argv[1])
        app = QApplication(sys.argv)
        app.setWindowIcon(QIcon('icons/python.gif'))
        mw = MainWindow()
        mw.show()
        sys.exit(app.exec_())
    elif len(sys.argv)==3 and sys.argv[2]=='-d':
        sys.stdout = sys.__stdout__
        mydb = DB(database=sys.argv[1])
        app = QApplication(sys.argv)
        mw = MainWindow()
        mw.show()
        sys.exit(app.exec_())
    else:
        sys.stdout = sys.__stdout__
        print 'Usage: python dbcontrol.py <db_name> [-d]'
        sys.exit(1)

if __name__ == '__main__':
    main()
    foo_dbg.close()
