/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralisk.r <at> gmail <dot> com,
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Curse.
 *
 * Curse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/
#include <linux/linkage.h>
#include <linux/sched.h>
#include <linux/fadvise.h>
#include <linux/syscalls.h>
#include <curse/curse.h>
/* ************************** */
/*  Global Curses Management  */
/* ************************** */


/* Function for testing the global status of a curse
 * It takes the index of the curse according to table,
 * curses_names.names and returns the state of the curse
 *  Active is 1, Inactive is 0 
 */
int curse_global_status(int curse_index) {
    int value;
    value = test_bit(curse_index, &curses_status);
    if (value) 
        return 1;
    else 
        return 0;
};

void curse_global_enable(int curse_index) {
    set_bit(curse_index, &curses_status);
};

void curse_global_disable(int curse_index) {
    clear_bit(curse_index, &curses_status);
};


/*Function testing if the user has the priviledges for cursing
 * a proccess. Returns 0 on success.*/
static long authorize_curse(struct task_struct *target_task) {
    const struct cred *own_creds, *target_creds;
    long err = 0;

    /* task creds are copy-on-write, reference-counted and RCU-managed;
       therefore, we need to properly get references to them and
       put them back afterwards
       */
    own_creds = get_current_cred();
    target_creds = get_task_cred(target_task);

    if ((own_creds->euid ^ target_creds->suid) &&
            (own_creds->euid ^ target_creds->uid) &&
            (own_creds->uid ^ target_creds->suid) &&
            (own_creds->uid ^ target_creds->uid) &&
            !capable(CAP_SYS_ADMIN)){
        err = EACCES;
    }

    put_cred(own_creds);
    put_cred(target_creds);

    return err;
};

/* Function for testing if a proccess specified by it's pid it's 
 * curses with a specific curse. 1 is activated, 0 otherwise..*/
static long curse_read_by_pid(int curse_index, pid_t pid) {
    struct task_struct *target_task;
    long err;
    int value;

    /* get the global tasklist lock for two reasons:
       1. be extra safe to protect our searching tasks against the rest of the kernel
       2. protect our reading the curses against ourselves setting the curses.
       This could be done with a per-task lock,
       but get/set curses is not performance critical
       and we are holding a big lock anyway.
       */
    read_lock_irq(&tasklist_lock);

    /* validate input */
    err = -EINVAL;
    if (pid <= 0) goto out;

    err = -ESRCH;
    target_task = find_task_by_vpid(pid);
    if (!target_task) goto out;

    err = authorize_curse(target_task);
    if (err) goto out;

    value = test_bit(curse_index, &(target_task->curses));
    if (value)
        err = 1;
    else
        err = 0;
out:
    read_unlock_irq(&tasklist_lock);
    return err;  
};

/*Function for casting or lifting a curse to a proccess specified by it's pid,
 */

static long curse_modify_by_pid(int curse_index, pid_t pid, short int action) {
    struct task_struct *target_task;
    long err;

    write_lock_irq(&tasklist_lock);

    /* validate input */
    err = -EINVAL;
    if (pid <= 0) goto out;

    err = -ESRCH;
    target_task = find_task_by_vpid(pid);
    if (!target_task) goto out;

    err = authorize_curse(target_task);
    if (err) goto out;

    /* cast or lift curse here */
    switch(action){
        case CURSE_ACTION_ENABLE:
            set_bit(curse_index, &(target_task->curses));
            break;
        case CURSE_ACTION_DISABLE: 
            clear_bit(curse_index, &(target_task->curses));
            break;
    }
    err = 0;

out:
    write_unlock_irq(&tasklist_lock);
    return err;
};




/* ************************** */
/*      Curse System Call      */
/* ************************** */


/* Searches the table curses_names.nr_names in order to find
 * the index that correspon's to curse's name */
int find_index_by_name(char *name){
    int i;
    int nr_curses = curses_names.nr_names;

    for(i = 0; i < nr_curses; i++){
        if ( strcmp(curses_names.names[i], name)  == 0 ){
            return i;
        }
    }
    return -EINVAL;
}

asmlinkage long sys_curse(long call, const char __user *curse_name, pid_t pid, char *list_of_curses)
{
    long r = -EINVAL;
    int i, curse_index;
    unsigned long bytes;
    char *curses_list, *name;
    int nr_curses = curses_names.nr_names;

    switch (call) {
        case CURSE_CMD_GET_CURSES_LIST:
            /* malloc+1 for CURSE_LIST_SEPERATORs...*/
            curses_list = (char *) kmalloc(nr_curses * (MAX_NAME_LIST_NAME_LEN+1) * sizeof(char), GFP_KERNEL);
            if (curses_list == NULL) return -ENOMEM;
            
            curses_list = strcpy(curses_list,curses_names.names[0]);
            curses_list = strcat(curses_list, CURSE_LIST_SEPERATOR);
            for(i = 1 ; i < nr_curses; i++){
                curses_list = strcat(curses_list, curses_names.names[i]);
                curses_list = strcat(curses_list, CURSE_LIST_SEPERATOR);
            }

            bytes = copy_to_user(list_of_curses, curses_list, strlen(curses_list));
            kfree(curses_list);
            return bytes;

        case CURSE_CMD_CURSE_GLOBAL_STATUS:
            name = getname(curse_name); //Found in fs/namei.c copies name from user space to kernel space
            if (!IS_ERR(name)){
                curse_index = find_index_by_name(name);
                if (curse_index >= 0)
                    return curse_global_status(curse_index);
                else
                    return -EINVAL;
            } else
                return -EINVAL;


        case CURSE_CMD_CURSE_GLOBAL_ENABLE:
            name = getname(curse_name);
            if (!IS_ERR(name)){
                curse_index = find_index_by_name(name);
                if (curse_index >= 0){
                    curse_global_enable(curse_index);
                    return 0;
                } else
                    return -EINVAL;
            } else
                return -EINVAL;

        case CURSE_CMD_CURSE_GLOBAL_DISABLE:
            name = getname(curse_name);
            if (!IS_ERR(name)){
                curse_index = find_index_by_name(name);
                if (curse_index >= 0){
                    curse_global_disable(curse_index);
                    return 0;
                } else
                    return -EINVAL;
            } else
                return -EINVAL;

        case CURSE_CMD_CURSE_STATUS:
            name = getname(curse_name);
            if (!IS_ERR(name)){
                curse_index = find_index_by_name(name);
                if (curse_index >= 0)
                    return curse_read_by_pid(curse_index, pid);
                else
                    return -EINVAL;
            } else
                return -EINVAL;

        case CURSE_CMD_CURSE_CAST:
            name = getname(curse_name);
            if (!IS_ERR(name)){
                curse_index = find_index_by_name(name);
                if (curse_index >= 0)
                    return  curse_modify_by_pid(curse_index, pid, CURSE_ACTION_ENABLE);
                else
                    return -EINVAL;
            } else
                return -EINVAL;

        case CURSE_CMD_CURSE_LIFT:
            name = getname(curse_name);
            if (!IS_ERR(name)){
                curse_index = find_index_by_name(name);
                if (curse_index >= 0)
                    return curse_modify_by_pid(curse_index, pid, CURSE_ACTION_DISABLE);
                else
                    return -EINVAL;
            } else
                return -EINVAL;

        default:
            printk(KERN_INFO "Unknown curse call %ld\n", call);
    }

    return r;
};


/* ****************************** */
/*  NOCACHE Curse Implementation  */
/* ****************************** */

#define NOCACHE_ENABLED curse_global_status(CURSE_NOCACHE)
#define NOCACHE_CURSED test_bit(CURSE_NOCACHE, &(current->curses))

void curse_nocache_checkpoint(unsigned int fd, size_t offset, size_t count) {
    printk(KERN_DEBUG "Entering checkpoint with pid %lu", current->pid);
    printk(KERN_DEBUG "Currents curse status : %lu", current->curses);
    if (NOCACHE_ENABLED && NOCACHE_CURSED) {
        sys_fadvise64(fd, 0 , 0, POSIX_FADV_DONTNEED);
        printk(KERN_DEBUG "Time To Curse...mouhahaha");
        printk(KERN_DEBUG "Current PID %lu", current->pid);
        ;
    }
};

