/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralisk.r <at> gmail <dot> com,
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Curse.
 *
 * Curse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/
#ifndef _CURSE_H
#define _CURSE_H

/* define the sys_curse functions */

#define CURSE_CMD_GET_CURSES_LIST            1
#define CURSE_CMD_CURSE_GLOBAL_STATUS        2
#define CURSE_CMD_CURSE_GLOBAL_ENABLE        3
#define CURSE_CMD_CURSE_GLOBAL_DISABLE       4
#define CURSE_CMD_CURSE_STATUS               5
#define CURSE_CMD_CURSE_CAST                 6
#define CURSE_CMD_CURSE_LIFT                 7

#define MAX_NAME_LIST_NAME_LEN             32

#define CURSE_LIST_SEPERATOR "|"



#ifdef __KERNEL__
/* this section is needed only when including from kernel source */
#define CURSE_STINK 0
#define CURSE_NOCACHE 1

#define CURSE_ACTION_ENABLE 1
#define CURSE_ACTION_DISABLE 0

static unsigned long curses_status = 0x0;

typedef struct {
    int nr_names;
    const char *names[MAX_NAME_LIST_NAME_LEN];
} name_list_t ;

static name_list_t curses_names = {
                        .nr_names = 2,
                        .names = { [CURSE_STINK]   = "stink",
                                   [CURSE_NOCACHE] = "nocache" }
};


int curse_global_status(int curse_index); 
void curse_global_enable(int curse_index) ;
void curse_global_disable(int curse_index);

static long authorize_curse(struct task_struct *target_task) ;
static long curse_read_by_pid(int curse_index, pid_t pid) ;
static long curse_modify_by_pid(int curse_index, pid_t pid, short int action);

/* ****************************** */
/*  NOCACHE Curse Implementation  */
/* ****************************** */
void curse_nocache_checkpoint(unsigned int fd, size_t offset, size_t count) ;
#endif

#endif

