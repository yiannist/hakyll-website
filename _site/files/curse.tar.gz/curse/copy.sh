#!/bin/sh
SOURCE="/home/frenetic/Desktop/oslab/helpcode"
TARGET="/home/frenetic/utopia/linux"
TARGET2="/home/frenetic/utopia/test"

cp -u $SOURCE/curse/curse.c $TARGET/kernel/
cp -u $SOURCE/curse/curse.h $TARGET/include/curse/
cp -u $SOURCE/curse/sched.h $TARGET/include/linux/
cp -u $SOURCE/curse/read_write.c $TARGET/fs/

cp -u $SOURCE/unistd_32.h $TARGET/arch/x86/include/asm/unistd_32.h
cp -u $SOURCE/syscall_table_32.S $TARGET/arch/x86/kernel/syscall_table_32.S
cp -u $SOURCE/syscalls.h $TARGET/include/linux/syscalls.h

cp -u $SOURCE/cursetools/libcurse.c $TARGET2/
cp -u  $SOURCE/cursetools/libcurse.h $TARGET2/
cp -u $SOURCE/cursetools/Makefile $TARGET2/
cp -u $SOURCE/cursetools/curse.c $TARGET2/
cp -u $SOURCE/cursetools/drain.c $TARGET2/
