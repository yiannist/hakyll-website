/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralisk.r <at> gmail <dot> com,
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Curse.
 *
 * Curse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/
#define _XOPEN_SOURCE 600
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

#define BUFLEN 4096
#define THRESH 8*1024*1024

int main(int argc, char **argv) {
    char *buf;
    int err;
    unsigned long counter = 0;

    if (argc > 1) {
        printf("Usage: ./drain  < infile  > outfile\n"
               "Simple pipe from standard input to standard output.\n"
               "Uses fadvise to suppress caching (needs files, won't work with pipes).\n");
        return -1;
    }

    buf = malloc(BUFLEN);
    if (!buf) {
        perror("malloc");
        return -1;
    }

    for (;;) {
         int b;

         err = read(0, buf, BUFLEN);
         if (err == 0) break;
         if (err < 0) {
             perror("read");
             return err;
         }

         b = err;
         counter += b;

         while (b > 0) {
             err = write(1, buf, b);
             if (err < 0) {
                 perror("write");
                 return err;
             }
             b -= err;
         }

         if (counter > THRESH) {
             counter = 0;
             posix_fadvise(0, 0, 0, POSIX_FADV_DONTNEED);
             posix_fadvise(1, 0, 0, POSIX_FADV_DONTNEED);
             /* Ignore errors (from pipes, etc.) */
         } 
    }

    return 0;
}
