/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralisk.r <at> gmail <dot> com,
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Curse.
 *
 * Curse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#include "libcurse.h"

long curse(long call, const char *curse_name, pid_t pid, char *curses_list) {
    return syscall(__NR_curse, call, curse_name, pid, curses_list );
}

long curse_global_status(const char *curse_name){
    return curse(CURSE_CMD_CURSE_GLOBAL_STATUS, curse_name, NULL, NULL);
}

long curse_enable(const char *curse_name) {
    return curse(CURSE_CMD_CURSE_GLOBAL_ENABLE, curse_name, NULL, NULL);
}

long curse_disable(const char *curse_name) {
    return curse(CURSE_CMD_CURSE_GLOBAL_DISABLE, curse_name, NULL, NULL);
}

long curse_status(const char *curse_name, pid_t pid) {
    return curse(CURSE_CMD_CURSE_STATUS, curse_name, pid, NULL);
}

long curse_cast(const char *curse_name, pid_t pid) {
    return curse(CURSE_CMD_CURSE_CAST, curse_name, pid, NULL);
}

long curse_lift(const char *curse_name, pid_t pid) {
    return curse(CURSE_CMD_CURSE_LIFT, curse_name, pid, NULL);
}


long curse_list(char *curses_list){
    return curse(CURSE_CMD_GET_CURSES_LIST, NULL, NULL, curses_list);
}


int curse_print_list(char *curse_list) {
    char *name;
    char *list;
    int i = 1;
    
    list = strdup(curse_list);
    name = strtok(list, CURSE_LIST_SEPERATOR);
    
    printf("Available Curses:\n"
            "Number\tName\n");
    while(name != NULL){
        printf("%d\t%s\n", i, name);
        name = strtok(NULL, CURSE_LIST_SEPERATOR);
        i++;
    }
    return 0;
}
