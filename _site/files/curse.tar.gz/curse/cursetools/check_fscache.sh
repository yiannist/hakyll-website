#!/bin/sh
#############################################################################
 #
 # This file is part of Curse.
 #
 # Curse is free software: you can redistribute it and/or modify
 # it under the terms of the GNU General Public License as published by
 # the Free Software Foundation, either version 3 of the License, or
 # (at your option) any later version.
 #
 # This program is distributed in the hope that it will be useful,
 # but WITHOUT ANY WARRANTY; without even the implied warranty of
 # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 # GNU General Public License for more details.
 #
 # You should have received a copy of the GNU General Public License
 # along with this program.  If not, see <http://www.gnu.org/licenses/>.
 #
 #############################################################################

if ! [ -e /big0 ]; then
	echo "creating big0..."
	dd if=/dev/zero of=/big0 bs=1024k count=100
	echo " "
fi

if ! [ -e /big1 ]; then
	echo "creating big1..."
	dd if=/dev/zero of=/big1 bs=1024k count=100
	echo " "
fi

./uncache /big0
./uncache /big1

echo "1st read..."
dd if=/big0 of=/dev/null bs=512k
echo " "

echo "2st read..."
dd if=/big0 of=/dev/null bs=512k
echo " "

echo "disrupt and press enter..."
read c

sleep 1

echo "3rd read..."
dd if=/big0 of=/dev/null bs=512k
echo " "

