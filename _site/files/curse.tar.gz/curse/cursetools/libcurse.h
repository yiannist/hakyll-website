/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralisk.r <at> gmail <dot> com,
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Curse.
 *
 * Curse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/

#ifndef LIBCURSE_H
#define LIBCURSE_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <errno.h>
#include <sys/types.h>
#include <linux/unistd.h>

#include <curse/curse.h>
#define __NR_curse 338
#define _GNU_SOURCE

long curse(long call, const char *curse_name, pid_t pid, char *curses_list);

long curse_global_status(const char *curse_name );
long curse_enable(const char *curse_name );
long curse_disable(const char *curse_name );
long curse_status(const char *curse_name , pid_t pid);
long curse_cast(const char *curse_name , pid_t pid);
long curse_lift(const char *curse_name , pid_t pid);
long curse_list(char *curses_list);

int curse_print_list(char *curses_list);
#endif
