/*****************************************************************************
 *
 * Authors: Chris Stavrakakis (frenetic), Yiannis Tsiouris (yiannis_t)
 * Contact: hydralisk.r <at> gmail <dot> com,
 *          yiannis.tsiouris <at> gmail <dot> com
 *
 * This file is part of Curse.
 *
 * Curse is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#define  SHELL_CMDLINE_SZ 100

#include "libcurse.h"


void help(void) {
 printf(
       "Usage:  <global action>\n"
       "Usage:  <cursename> <action> [<option>]\n"
       "\n"
       " Global Actions                   Description\n"
       "----------------        ---------------------\n"
       "     help               show this help\n"
       "     list               list curses\n"
       "\n"
       " Curse Actions                    Description\n"
       "----------------        ---------------------\n"
       "       ?                show curse global status (enabled/disabled)\n"
       "       +                enable curse <cursename>\n"
       "       -                disable curse <cursename>\n"
       "\n"
       "     <pid>+             curse <pid> with <cursename>\n"
       "     <pid>-             lift curse <cursename> from pid\n"
       "     <pid>?             show <cursename> status for pid\n"
       "\n"
       "   Examples                        Description\n"
       "----------------        ---------------------\n"
       " list              show a list of available curses\n"
       " nocache ?         show if curse 'nocache' is enabled \n"
       " nocache +         enable curse 'nocache' \n"
       " nocache 7423?     show if process 7423 is cursed with 'nocache' \n"
       " nocache 7423+     curse process 7423 with 'nocache' \n"
       "\n"
    );
}





void get_cmd_line(FILE *fp, char *buf, int bufsz){
    
    if (fgets(buf, bufsz, fp) == NULL) {
        fprintf(stderr, "Shell: could not read command line, exiting.\n");
        exit(1);
    }
    if (buf[strlen(buf) - 1] == '\n')
        buf[strlen(buf) - 1] = '\0';
}




void proccess_cmdline(char *cmdline){
    const char delimiters[] = " ";
    char *cp,*name,*action,*pid_name;
    pid_t pid; 
    int length;
    long res;
    char *mylist;

    /* Quit */
    if (strcmp(cmdline, "q") == 0){
        fprintf(stderr, "Shell Exiting, Goodbye\n");
        exit(0);
    }

    if(strcmp(cmdline, "c")==0){
        system("clear");
        return;
    }
    /* Help */
    if (strcmp(cmdline, "help") == 0){
        help();
        return;
    }

    /* List */
    if (strcmp(cmdline, "list") == 0){
        res = curse_list(NULL);
        mylist = (char *)malloc(res * sizeof(char));
        res = curse_list(mylist);
        if (!res)
            curse_print_list(mylist);
        else
            perror("Listing:");
        free(mylist);
        return;
        
    }

    cp = strdup(cmdline);
    
    name = strtok (cp, delimiters);
    if (name == NULL) {
        printf("Wrong Usage\n");
        return;
    }
    
    action = strtok (NULL, delimiters);
    if (action == NULL) {
        printf("Wrong Usage\n");
        return;
    }

    /* Curse Global Status */
    if (strcmp(action, "?") == 0){
        res = curse_global_status(name);
        if (res < 0)
            perror("Curse Status:");
        else
        {
            if (res) 
                printf("Curse %s is Enabled\n",name);
            else
                printf("Curse %s is Disabled\n",name);
        }
        return;
    }

    /* Curse Enable */
    if (strcmp(action,"+") == 0){
        res = curse_enable(name);
        if (res < 0) 
            perror("Curse Enable:");
        return;
    }

    /* Curse Disable */
    if (strcmp(action,"-") == 0){
        res = curse_disable(name);
        if (res<0) 
            perror("Curse Disable");
        return;
    }

    length = strlen(action);
    pid_name = malloc( length * sizeof(char));
    if (pid_name == NULL){
        printf("Out of Memory\n");
        return;
    }
    pid_name = strncpy(pid_name, action, length-1);
    pid = atoi(pid_name);
    action = action + length - 1;

    if (strcmp(action,"?") == 0){
        res = curse_status(name, pid);
        if (res < 0)
            perror("Proccess Curse Status:");
        else {
            if (res) 
                printf("Curse %s for %lu proccess is Enabled\n", name, (unsigned long) pid);
            else
                printf("Curse %s for %lu proccess is Disabled\n",name, (unsigned long) pid);
        }
        return;
    }

    if (strcmp(action,"+")==0){
        res = curse_cast(name,pid);
        if (res<0) 
            perror("Proccess Curse Casting:");
        return ;
    }

    if (strcmp(action,"-")==0){
        res = curse_lift(name, pid);
        if (res<0) 
            perror("Proccess Curse Lifting");
        return ;
    }

    /*Cannot reach this point if command is correct)*/
    printf("Wrong Usage\n");
    return;
}




int main(int argc, char **argv) {
    char cmdline[SHELL_CMDLINE_SZ];
    system("clear");
    printf("\n############################################################\n"
            "#  Welcome To Curse User Tool                              #\n"
            "############################################################\n");
    help();
    for (;;) {
        printf("curse> ");
        fflush(stdout);
        get_cmd_line(stdin, cmdline, SHELL_CMDLINE_SZ);
        proccess_cmdline(cmdline);
    }
    printf("Error: Reached unreachble point\n"); 
    return 1;
}



